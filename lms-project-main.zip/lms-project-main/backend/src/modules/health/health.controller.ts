import type { Request, Response } from 'express';

import { success } from '../../utils/apiResponse';

export const getHealth = (_req: Request, res: Response): void => {
  success(res, {
    status: 'ok',
    uptime: process.uptime(),
    timestamp: Date.now(),
  });
};
