import type { Request, Response } from 'express';

import { error as errorResponse, success } from '../../utils/apiResponse';
import {
  createSectionRecord,
  createSubjectRecord,
  getSubjectHierarchy,
  getSubjectMetadata,
  listSubjects,
  SubjectServiceError,
} from './subject.service';
import type {
  CreateSectionBody,
  CreateSubjectBody,
} from './subject.schemas';

type SubjectListQuery = {
  page?: string;
  pageSize?: string;
  q?: string;
};

type SubjectParams = {
  subjectId: string;
};

const parsePositiveInteger = (
  value: string | undefined,
  fallback: number,
): number => {
  if (!value) {
    return fallback;
  }

  const parsedValue = Number(value);

  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    return fallback;
  }

  return parsedValue;
};

const parseSubjectId = (value: string): number => {
  const subjectId = Number(value);

  if (!Number.isInteger(subjectId) || subjectId <= 0) {
    throw new SubjectServiceError('Invalid subjectId', 400);
  }

  return subjectId;
};

const getErrorResponse = (error: unknown): { statusCode: number; message: string } => {
  if (error instanceof SubjectServiceError) {
    return {
      statusCode: error.statusCode,
      message: error.message,
    };
  }

  return {
    statusCode: 500,
    message: 'Internal Server Error',
  };
};

type AuthenticatedRequest = Request & {
  user?: {
    id: number;
    email: string;
  };
};

export const list = async (
  req: Request<unknown, unknown, unknown, SubjectListQuery>,
  res: Response,
): Promise<void> => {
  try {
    const page = parsePositiveInteger(req.query.page, 1);
    const pageSize = parsePositiveInteger(req.query.pageSize, 10);
    const subjects = await listSubjects(page, pageSize, req.query.q);

    success(res, {
      page,
      pageSize,
      data: subjects,
    });
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const getById = async (
  req: Request<SubjectParams>,
  res: Response,
): Promise<void> => {
  try {
    const subjectId = parseSubjectId(req.params.subjectId);
    const subject = await getSubjectMetadata(subjectId);

    success(res, subject);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const getTree = async (
  req: AuthenticatedRequest & Request<SubjectParams>,
  res: Response,
): Promise<void> => {
  try {
    const subjectId = parseSubjectId(req.params.subjectId);
    const userId = req.user?.id ?? null;
    const subjectTree = await getSubjectHierarchy(subjectId, userId);

    success(res, subjectTree);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const create = async (
  req: Request<unknown, unknown, CreateSubjectBody>,
  res: Response,
): Promise<void> => {
  try {
    const { title, slug, description, isPublished } = req.body;
    const subject = await createSubjectRecord(
      title,
      slug,
      description ?? null,
      isPublished ?? false,
    );

    success(res, subject, 201);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const createSection = async (
  req: Request<SubjectParams, unknown, CreateSectionBody>,
  res: Response,
): Promise<void> => {
  try {
    const subjectId = parseSubjectId(req.params.subjectId);
    const { title, orderIndex } = req.body;
    const section = await createSectionRecord(subjectId, title, orderIndex);

    success(res, section, 201);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};
