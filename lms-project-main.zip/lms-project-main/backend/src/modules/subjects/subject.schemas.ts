import { z } from 'zod';

export const createSubjectSchema = z.object({
  title: z.string().trim().min(1).max(255),
  slug: z.string().trim().min(1).max(255),
  description: z.string().trim().max(5000).nullable().optional(),
  isPublished: z.boolean().optional().default(false),
});

export const createSectionSchema = z.object({
  title: z.string().trim().min(1).max(255),
  orderIndex: z.number().int().min(1),
});

export type CreateSubjectBody = z.infer<typeof createSubjectSchema>;
export type CreateSectionBody = z.infer<typeof createSectionSchema>;
