import { getVideoProgress } from '../progress/progress.repository';
import { buildVideoLockMap } from '../../utils/ordering';
import {
  createSection,
  createSubject,
  type CreatedSection,
  type CreatedSubject,
  getSubjectById,
  getSubjectByIdIncludingUnpublished,
  getSubjects,
  getSubjectTree,
  type SubjectSummary,
  type SubjectTree,
} from './subject.repository';

export class SubjectServiceError extends Error {
  public readonly statusCode: number;

  public constructor(message: string, statusCode: number) {
    super(message);
    this.name = 'SubjectServiceError';
    this.statusCode = statusCode;
  }
}

export const listSubjects = async (
  page: number,
  pageSize: number,
  query?: string,
): Promise<SubjectSummary[]> => {
  return getSubjects(page, pageSize, query);
};

export const getSubjectMetadata = async (
  subjectId: number,
): Promise<SubjectSummary> => {
  const subject = await getSubjectById(subjectId);

  if (!subject) {
    throw new SubjectServiceError('Subject not found', 404);
  }

  return subject;
};

export const getSubjectHierarchy = async (
  subjectId: number,
  userId: number | null,
): Promise<SubjectTree> => {
  const subjectTree = await getSubjectTree(subjectId);

  if (!subjectTree) {
    throw new SubjectServiceError('Subject not found', 404);
  }

  const subjectVideos = subjectTree.sections.flatMap((section) => section.videos);
  const subjectVideoSequence = subjectTree.sections.flatMap((section) =>
    section.videos.map((video) => ({
      id: video.id,
      subject_id: subjectId,
      section_id: section.id,
      title: video.title,
      order_index: video.order_index,
    })),
  );
  const videoLockMap = await buildVideoLockMap(userId, subjectVideoSequence);

  for (const video of subjectVideos) {
    const progress = userId === null
      ? { is_completed: false }
      : await getVideoProgress(userId, video.id);
    const lockState = videoLockMap.get(video.id) ?? { locked: false };

    video.is_completed = progress.is_completed;
    video.locked = lockState.locked;
  }

  return subjectTree;
};

export const createSubjectRecord = async (
  title: string,
  slug: string,
  description: string | null,
  isPublished: boolean,
): Promise<CreatedSubject> => {
  return createSubject(title, slug, description, isPublished);
};

export const createSectionRecord = async (
  subjectId: number,
  title: string,
  orderIndex: number,
): Promise<CreatedSection> => {
  const subject = await getSubjectByIdIncludingUnpublished(subjectId);

  if (!subject) {
    throw new SubjectServiceError('Subject not found', 404);
  }

  return createSection(subjectId, title, orderIndex);
};
