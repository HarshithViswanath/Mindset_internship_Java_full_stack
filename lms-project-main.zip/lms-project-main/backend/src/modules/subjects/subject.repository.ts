import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';

import { pool } from '../../config/db';

export type SubjectSummary = {
  id: number;
  title: string | null;
  slug: string | null;
  description: string | null;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
};

export type CreatedSubject = SubjectSummary;

export type CreatedSection = {
  id: number;
  subjectId: number;
  title: string | null;
  orderIndex: number | null;
  createdAt: Date;
  updatedAt: Date;
};

export type SubjectTreeVideo = {
  id: number;
  title: string | null;
  order_index: number | null;
  is_completed: boolean;
  locked: boolean;
};

export type SubjectTreeSection = {
  id: number;
  title: string | null;
  order_index: number | null;
  videos: SubjectTreeVideo[];
};

export type SubjectTree = {
  id: number;
  title: string | null;
  sections: SubjectTreeSection[];
};

type SubjectRow = RowDataPacket & {
  id: number;
  title: string | null;
  slug: string | null;
  description: string | null;
  is_published: number;
  created_at: Date;
  updated_at: Date;
};

type SubjectTreeRow = RowDataPacket & {
  subject_id: number;
  subject_title: string | null;
  section_id: number | null;
  section_title: string | null;
  section_order_index: number | null;
  video_id: number | null;
  video_title: string | null;
  video_order_index: number | null;
};

type CreatedSectionRow = RowDataPacket & {
  id: number;
  subject_id: number;
  title: string | null;
  order_index: number | null;
  created_at: Date;
  updated_at: Date;
};

const mapSubject = (row: SubjectRow): SubjectSummary => {
  return {
    id: row.id,
    title: row.title,
    slug: row.slug,
    description: row.description,
    isPublished: Boolean(row.is_published),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
};

export const getSubjects = async (
  page: number,
  pageSize: number,
  query?: string,
): Promise<SubjectSummary[]> => {
  const offset = (page - 1) * pageSize;
  const normalizedQuery = query?.trim();

  const whereClauses = ['is_published = TRUE'];
  const parameters: Array<string | number> = [];

  if (normalizedQuery) {
    whereClauses.push('(title LIKE ? OR description LIKE ? OR slug LIKE ?)');
    const searchTerm = `%${normalizedQuery}%`;
    parameters.push(searchTerm, searchTerm, searchTerm);
  }

  parameters.push(pageSize, offset);

  const [rows] = await pool.query<SubjectRow[]>(
    `
      SELECT id, title, slug, description, is_published, created_at, updated_at
      FROM subjects
      WHERE ${whereClauses.join(' AND ')}
      ORDER BY created_at DESC, id DESC
      LIMIT ? OFFSET ?
    `,
    parameters,
  );

  return rows.map(mapSubject);
};

export const getSubjectById = async (
  subjectId: number,
): Promise<SubjectSummary | null> => {
  const [rows] = await pool.execute<SubjectRow[]>(
    `
      SELECT id, title, slug, description, is_published, created_at, updated_at
      FROM subjects
      WHERE id = ? AND is_published = TRUE
      LIMIT 1
    `,
    [subjectId],
  );

  const subject = rows[0];

  return subject ? mapSubject(subject) : null;
};

export const getSubjectByIdIncludingUnpublished = async (
  subjectId: number,
): Promise<SubjectSummary | null> => {
  const [rows] = await pool.execute<SubjectRow[]>(
    `
      SELECT id, title, slug, description, is_published, created_at, updated_at
      FROM subjects
      WHERE id = ?
      LIMIT 1
    `,
    [subjectId],
  );

  const subject = rows[0];

  return subject ? mapSubject(subject) : null;
};

export const getSubjectTree = async (
  subjectId: number,
): Promise<SubjectTree | null> => {
  const [rows] = await pool.execute<SubjectTreeRow[]>(
    `
      SELECT
        s.id AS subject_id,
        s.title AS subject_title,
        sec.id AS section_id,
        sec.title AS section_title,
        sec.order_index AS section_order_index,
        v.id AS video_id,
        v.title AS video_title,
        v.order_index AS video_order_index
      FROM subjects s
      LEFT JOIN sections sec ON sec.subject_id = s.id
      LEFT JOIN videos v ON v.section_id = sec.id
      WHERE s.id = ? AND s.is_published = TRUE
      ORDER BY sec.order_index ASC, sec.id ASC, v.order_index ASC, v.id ASC
    `,
    [subjectId],
  );

  const firstRow = rows[0];

  if (!firstRow) {
    return null;
  }

  const sectionsMap = new Map<number, SubjectTreeSection>();
  const subjectTree: SubjectTree = {
    id: firstRow.subject_id,
    title: firstRow.subject_title,
    sections: [],
  };

  for (const row of rows) {
    if (row.section_id === null) {
      continue;
    }

    let section = sectionsMap.get(row.section_id);

    if (!section) {
      section = {
        id: row.section_id,
        title: row.section_title,
        order_index: row.section_order_index,
        videos: [],
      };
      sectionsMap.set(row.section_id, section);
      subjectTree.sections.push(section);
    }

    if (row.video_id !== null) {
      section.videos.push({
        id: row.video_id,
        title: row.video_title,
        order_index: row.video_order_index,
        is_completed: false,
        locked: false,
      });
    }
  }

  return subjectTree;
};

export const createSubject = async (
  title: string,
  slug: string,
  description: string | null,
  isPublished: boolean,
): Promise<CreatedSubject> => {
  const [result] = await pool.execute<ResultSetHeader>(
    `
      INSERT INTO subjects (title, slug, description, is_published)
      VALUES (?, ?, ?, ?)
    `,
    [title, slug, description, isPublished],
  );

  const [rows] = await pool.execute<SubjectRow[]>(
    `
      SELECT id, title, slug, description, is_published, created_at, updated_at
      FROM subjects
      WHERE id = ?
      LIMIT 1
    `,
    [result.insertId],
  );

  const subject = rows[0];

  if (!subject) {
    throw new Error('Failed to load created subject');
  }

  return mapSubject(subject);
};

export const createSection = async (
  subjectId: number,
  title: string,
  orderIndex: number,
): Promise<CreatedSection> => {
  const [result] = await pool.execute<ResultSetHeader>(
    `
      INSERT INTO sections (subject_id, title, order_index)
      VALUES (?, ?, ?)
    `,
    [subjectId, title, orderIndex],
  );

  const [rows] = await pool.execute<CreatedSectionRow[]>(
    `
      SELECT id, subject_id, title, order_index, created_at, updated_at
      FROM sections
      WHERE id = ?
      LIMIT 1
    `,
    [result.insertId],
  );

  const section = rows[0];

  if (!section) {
    throw new Error('Failed to load created section');
  }

  return {
    id: section.id,
    subjectId: section.subject_id,
    title: section.title,
    orderIndex: section.order_index,
    createdAt: section.created_at,
    updatedAt: section.updated_at,
  };
};
