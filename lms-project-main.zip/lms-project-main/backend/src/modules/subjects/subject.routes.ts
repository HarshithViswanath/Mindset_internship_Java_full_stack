import { Router } from 'express';

import { authenticate } from '../../middleware/authenticate';
import { requireAdmin } from '../../middleware/requireAdmin';
import { requireSubjectEnrollment } from '../../middleware/requireEnrollment';
import { validateBody } from '../../middleware/validation/validateBody';
import {
  create,
  createSection,
  getById,
  getTree,
  list,
} from './subject.controller';
import {
  createSectionSchema,
  createSubjectSchema,
} from './subject.schemas';

const subjectRoutes = Router();

subjectRoutes.get('/', list);
subjectRoutes.post(
  '/',
  authenticate,
  requireAdmin,
  validateBody(createSubjectSchema),
  create,
);
subjectRoutes.get('/:subjectId', getById);
subjectRoutes.post(
  '/:subjectId/sections',
  authenticate,
  requireAdmin,
  validateBody(createSectionSchema),
  createSection,
);
subjectRoutes.get('/:subjectId/tree', authenticate, requireSubjectEnrollment, getTree);

export { subjectRoutes };
