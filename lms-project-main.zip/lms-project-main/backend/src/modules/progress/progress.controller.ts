import type { Request, Response } from 'express';

import { error as errorResponse, success } from '../../utils/apiResponse';
import { isVideoLocked } from '../../utils/ordering';
import {
  getUserSubjectProgress,
  getUserVideoProgress,
  ProgressServiceError,
  saveUserVideoProgress,
} from './progress.service';

type VideoParams = {
  videoId: string;
};

type SubjectParams = {
  subjectId: string;
};

type UpdateProgressBody = {
  last_position_seconds?: number;
  is_completed?: boolean;
};

type AuthenticatedRequest = Request & {
  user?: {
    id: number;
    email: string;
  };
};

const parsePositiveInteger = (value: string, fieldName: string): number => {
  const parsedValue = Number(value);

  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    throw new ProgressServiceError(`Invalid ${fieldName}`, 400);
  }

  return parsedValue;
};

const getAuthenticatedUserId = (req: AuthenticatedRequest): number => {
  const userId = Number(req.user?.id);

  if (!Number.isInteger(userId) || userId <= 0) {
    throw new ProgressServiceError('Unauthorized', 401);
  }

  return userId;
};

const getErrorResponse = (error: unknown): { statusCode: number; message: string } => {
  if (error instanceof ProgressServiceError) {
    return {
      statusCode: error.statusCode,
      message: error.message,
    };
  }

  return {
    statusCode: 500,
    message: 'Internal Server Error',
  };
};

export const getVideoProgressById = async (
  req: AuthenticatedRequest & Request<VideoParams>,
  res: Response,
): Promise<void> => {
  try {
    const userId = getAuthenticatedUserId(req);
    const videoId = parsePositiveInteger(req.params.videoId, 'videoId');
    const progress = await getUserVideoProgress(userId, videoId);

    success(res, progress);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const updateVideoProgressById = async (
  req: AuthenticatedRequest & Request<VideoParams, unknown, UpdateProgressBody>,
  res: Response,
): Promise<void> => {
  try {
    const userId = getAuthenticatedUserId(req);
    const videoId = parsePositiveInteger(req.params.videoId, 'videoId');
    const { last_position_seconds, is_completed } = req.body;

    if (typeof last_position_seconds !== 'number' || Number.isNaN(last_position_seconds)) {
      errorResponse(res, 'last_position_seconds is required and must be a number', 400);
      return;
    }

    const lockState = await isVideoLocked(userId, videoId);

    if (lockState.locked) {
      throw new ProgressServiceError(
        lockState.unlock_reason ?? 'Video is locked',
        403,
      );
    }

    const progress = await saveUserVideoProgress(
      userId,
      videoId,
      last_position_seconds,
      is_completed ?? false,
    );

    success(res, progress);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const getSubjectProgressById = async (
  req: AuthenticatedRequest & Request<SubjectParams>,
  res: Response,
): Promise<void> => {
  try {
    const userId = getAuthenticatedUserId(req);
    const subjectId = parsePositiveInteger(req.params.subjectId, 'subjectId');
    const progress = await getUserSubjectProgress(userId, subjectId);

    success(res, progress);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const markVideoComplete = async (
  req: AuthenticatedRequest,
  res: Response,
): Promise<void> => {
  try {
    const currentUserId = getAuthenticatedUserId(req);
    const { user_id, video_id } = req.body;

    // Validate inputs
    if (!video_id || typeof video_id !== 'number') {
      errorResponse(res, 'video_id is required and must be a number', 400);
      return;
    }

    const targetUserId = user_id && typeof user_id === 'number' ? user_id : currentUserId;

    // Direct MySQL upsert according to the specification
    await import('../../config/db').then(({ pool }) =>
      pool.execute(
        `
          INSERT INTO video_progress (user_id, video_id, is_completed, last_position_seconds, completed_at)
          VALUES (?, ?, 1, 0, CURRENT_TIMESTAMP)
          ON DUPLICATE KEY UPDATE
            is_completed = 1,
            completed_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        `,
        [targetUserId, video_id],
      )
    );

    // Return exact mapping requested
    success(res, {
      video_id: video_id,
      completed: true,
    });
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};
