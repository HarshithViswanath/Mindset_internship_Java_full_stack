import type { RowDataPacket } from 'mysql2/promise';

import { pool } from '../../config/db';

export type VideoProgressRecord = {
  last_position_seconds: number;
  is_completed: boolean;
};

export type SubjectProgressRecord = {
  total_videos: number;
  completed_videos: number;
  percent_complete: number;
};

type VideoProgressRow = RowDataPacket & {
  last_position_seconds: number;
  is_completed: number;
};

type SubjectProgressRow = RowDataPacket & {
  total_videos: number;
  completed_videos: number;
};

export const getVideoProgress = async (
  userId: number,
  videoId: number,
): Promise<VideoProgressRecord> => {
  const [rows] = await pool.execute<VideoProgressRow[]>(
    `
      SELECT last_position_seconds, is_completed
      FROM video_progress
      WHERE user_id = ? AND video_id = ?
      LIMIT 1
    `,
    [userId, videoId],
  );

  const progress = rows[0];

  if (!progress) {
    return {
      last_position_seconds: 0,
      is_completed: false,
    };
  }

  return {
    last_position_seconds: progress.last_position_seconds,
    is_completed: Buffer.isBuffer(progress.is_completed) 
      ? progress.is_completed[0] === 1 
      : Number(progress.is_completed) === 1,
  };
};

export const upsertVideoProgress = async (
  userId: number,
  videoId: number,
  lastPositionSeconds: number,
  isCompleted: boolean,
): Promise<VideoProgressRecord> => {
  await pool.execute(
    `
      INSERT INTO video_progress (
        user_id,
        video_id,
        last_position_seconds,
        is_completed,
        completed_at
      )
      VALUES (?, ?, ?, ?, CASE WHEN ? THEN CURRENT_TIMESTAMP ELSE NULL END)
      ON DUPLICATE KEY UPDATE
        last_position_seconds = VALUES(last_position_seconds),
        is_completed = VALUES(is_completed),
        completed_at = CASE
          WHEN VALUES(is_completed) = TRUE THEN CURRENT_TIMESTAMP
          ELSE NULL
        END,
        updated_at = CURRENT_TIMESTAMP
    `,
    [userId, videoId, lastPositionSeconds, isCompleted, isCompleted],
  );

  return getVideoProgress(userId, videoId);
};

export const getSubjectProgress = async (
  userId: number,
  subjectId: number,
): Promise<SubjectProgressRecord> => {
  const [rows] = await pool.execute<SubjectProgressRow[]>(
    `
      SELECT
        COUNT(v.id) AS total_videos,
        COALESCE(SUM(CASE WHEN vp.is_completed = TRUE THEN 1 ELSE 0 END), 0) AS completed_videos
      FROM sections sec
      INNER JOIN videos v ON v.section_id = sec.id
      LEFT JOIN video_progress vp
        ON vp.video_id = v.id
        AND vp.user_id = ?
      WHERE sec.subject_id = ?
    `,
    [userId, subjectId],
  );

  const progress = rows[0] ?? {
    total_videos: 0,
    completed_videos: 0,
  };

  const totalVideos = Number(progress.total_videos) || 0;
  const completedVideos = Number(progress.completed_videos) || 0;
  const percentComplete =
    totalVideos === 0 ? 0 : Math.round((completedVideos / totalVideos) * 100);

  return {
    total_videos: totalVideos,
    completed_videos: completedVideos,
    percent_complete: percentComplete,
  };
};
