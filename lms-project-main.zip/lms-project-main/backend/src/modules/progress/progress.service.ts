import {
  getSubjectProgress,
  getVideoProgress,
  upsertVideoProgress,
  type SubjectProgressRecord,
  type VideoProgressRecord,
} from './progress.repository';

export class ProgressServiceError extends Error {
  public readonly statusCode: number;

  public constructor(message: string, statusCode: number) {
    super(message);
    this.name = 'ProgressServiceError';
    this.statusCode = statusCode;
  }
}

export const getUserVideoProgress = async (
  userId: number,
  videoId: number,
): Promise<VideoProgressRecord> => {
  return getVideoProgress(userId, videoId);
};

export const saveUserVideoProgress = async (
  userId: number,
  videoId: number,
  lastPositionSeconds: number,
  isCompleted: boolean,
): Promise<VideoProgressRecord> => {
  if (lastPositionSeconds < 0) {
    throw new ProgressServiceError(
      'last_position_seconds must be greater than or equal to 0',
      400,
    );
  }

  return upsertVideoProgress(
    userId,
    videoId,
    lastPositionSeconds,
    isCompleted,
  );
};

export const getUserSubjectProgress = async (
  userId: number,
  subjectId: number,
): Promise<SubjectProgressRecord> => {
  return getSubjectProgress(userId, subjectId);
};
