import { Router } from 'express';

import { authenticate } from '../../middleware/authenticate';
import {
  requireSubjectEnrollment,
  requireVideoEnrollment,
} from '../../middleware/requireEnrollment';
import {
  getSubjectProgressById,
  getVideoProgressById,
  updateVideoProgressById,
  markVideoComplete,
} from './progress.controller';

const progressRoutes = Router();

progressRoutes.post('/complete', authenticate, markVideoComplete);
progressRoutes.get('/videos/:videoId', authenticate, requireVideoEnrollment, getVideoProgressById);
progressRoutes.post('/videos/:videoId', authenticate, requireVideoEnrollment, updateVideoProgressById);
progressRoutes.get('/subjects/:subjectId', authenticate, requireSubjectEnrollment, getSubjectProgressById);

export { progressRoutes };
