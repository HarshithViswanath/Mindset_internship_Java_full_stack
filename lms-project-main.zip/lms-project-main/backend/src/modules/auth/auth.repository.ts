import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';

import { pool } from '../../config/db';

export type UserRecord = {
  id: number;
  email: string;
  passwordHash: string;
  name: string | null;
  isAdmin: boolean;
  createdAt: Date;
  updatedAt: Date;
};

export type RefreshTokenRecord = {
  id: number;
  userId: number;
  tokenHash: string;
  expiresAt: Date;
  revokedAt: Date | null;
  createdAt: Date;
};

type UserRow = RowDataPacket & {
  id: number;
  email: string;
  password_hash: string;
  name: string | null;
  is_admin: number;
  created_at: Date;
  updated_at: Date;
};

type RefreshTokenRow = RowDataPacket & {
  id: number;
  user_id: number;
  token_hash: string;
  expires_at: Date;
  revoked_at: Date | null;
  created_at: Date;
};

const mapUser = (row: UserRow): UserRecord => {
  return {
    id: row.id,
    email: row.email,
    passwordHash: row.password_hash,
    name: row.name,
    isAdmin: Boolean(row.is_admin),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
};

const mapRefreshToken = (row: RefreshTokenRow): RefreshTokenRecord => {
  return {
    id: row.id,
    userId: row.user_id,
    tokenHash: row.token_hash,
    expiresAt: row.expires_at,
    revokedAt: row.revoked_at,
    createdAt: row.created_at,
  };
};

export const createUser = async (
  email: string,
  passwordHash: string,
  name: string | null,
  isAdmin = false,
): Promise<UserRecord> => {
  const [result] = await pool.execute<ResultSetHeader>(
    `
      INSERT INTO users (email, password_hash, name, is_admin)
      VALUES (?, ?, ?, ?)
    `,
    [email, passwordHash, name, isAdmin],
  );

  const [rows] = await pool.execute<UserRow[]>(
    `
      SELECT id, email, password_hash, name, is_admin, created_at, updated_at
      FROM users
      WHERE id = ?
      LIMIT 1
    `,
    [result.insertId],
  );

  const user = rows[0];

  if (!user) {
    throw new Error('Failed to load created user');
  }

  return mapUser(user);
};

export const findUserByEmail = async (
  email: string,
): Promise<UserRecord | null> => {
  const [rows] = await pool.execute<UserRow[]>(
    `
      SELECT id, email, password_hash, name, is_admin, created_at, updated_at
      FROM users
      WHERE email = ?
      LIMIT 1
    `,
    [email],
  );

  const user = rows[0];

  return user ? mapUser(user) : null;
};

export const findUserById = async (userId: number): Promise<UserRecord | null> => {
  const [rows] = await pool.execute<UserRow[]>(
    `
      SELECT id, email, password_hash, name, is_admin, created_at, updated_at
      FROM users
      WHERE id = ?
      LIMIT 1
    `,
    [userId],
  );

  const user = rows[0];

  return user ? mapUser(user) : null;
};

const DEFAULT_ADMIN_EMAIL = 'admin@lms.com';
const DEFAULT_ADMIN_NAME = 'LMS Admin';

export const ensureAdminUserRecord = async (
  passwordHash: string,
): Promise<void> => {
  const [columnRows] = await pool.query<RowDataPacket[]>(
    `
      SHOW COLUMNS FROM users LIKE 'is_admin'
    `,
  );

  if (columnRows.length === 0) {
    await pool.execute(
      `
        ALTER TABLE users
        ADD COLUMN is_admin BOOLEAN NOT NULL DEFAULT FALSE
      `,
    );
  }

  const existingAdmin = await findUserByEmail(DEFAULT_ADMIN_EMAIL);

  if (!existingAdmin) {
    await createUser(DEFAULT_ADMIN_EMAIL, passwordHash, DEFAULT_ADMIN_NAME, true);
    return;
  }

  if (!existingAdmin.isAdmin) {
    await pool.execute(
      `
        UPDATE users
        SET is_admin = TRUE
        WHERE id = ?
      `,
      [existingAdmin.id],
    );
  }
};

export const storeRefreshToken = async (
  userId: number,
  tokenHash: string,
  expiresAt: Date,
): Promise<void> => {
  await pool.execute(
    `
      INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
      VALUES (?, ?, ?)
    `,
    [userId, tokenHash, expiresAt],
  );
};

export const findRefreshToken = async (
  tokenHash: string,
): Promise<RefreshTokenRecord | null> => {
  const [rows] = await pool.execute<RefreshTokenRow[]>(
    `
      SELECT id, user_id, token_hash, expires_at, revoked_at, created_at
      FROM refresh_tokens
      WHERE token_hash = ?
      LIMIT 1
    `,
    [tokenHash],
  );

  const refreshToken = rows[0];

  return refreshToken ? mapRefreshToken(refreshToken) : null;
};

export const revokeRefreshToken = async (tokenHash: string): Promise<void> => {
  await pool.execute(
    `
      UPDATE refresh_tokens
      SET revoked_at = CURRENT_TIMESTAMP
      WHERE token_hash = ? AND revoked_at IS NULL
    `,
    [tokenHash],
  );
};
