import { createHash } from 'node:crypto';

import { config } from '../../config/env';
import type { AuthTokenPayload } from '../../utils/jwt';
import {
  signAccessToken,
  signRefreshToken,
  verifyToken,
} from '../../utils/jwt';
import { comparePassword, hashPassword } from '../../utils/password';
import {
  createUser,
  ensureAdminUserRecord,
  findRefreshToken,
  findUserByEmail,
  findUserById,
  revokeRefreshToken,
  storeRefreshToken,
  type UserRecord,
} from './auth.repository';

type AuthUser = {
  id: number;
  email: string;
  name: string | null;
  isAdmin: boolean;
};

type AuthTokens = {
  accessToken: string;
  refreshToken: string;
};

type AuthResponse = {
  user: AuthUser;
} & AuthTokens;

export class AuthServiceError extends Error {
  public readonly statusCode: number;

  public constructor(message: string, statusCode: number) {
    super(message);
    this.name = 'AuthServiceError';
    this.statusCode = statusCode;
  }
}

const REFRESH_TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000;

const sanitizeUser = (user: UserRecord): AuthUser => {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    isAdmin: user.isAdmin,
  };
};

const getTokenHash = (token: string): string => {
  return createHash('sha256').update(token).digest('hex');
};

const buildTokens = async (user: UserRecord): Promise<AuthTokens> => {
  const payload: AuthTokenPayload = {
    userId: user.id,
    email: user.email,
    isAdmin: user.isAdmin,
  };

  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);
  const refreshTokenHash = getTokenHash(refreshToken);
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_MS);

  await storeRefreshToken(user.id, refreshTokenHash, expiresAt);

  return {
    accessToken,
    refreshToken,
  };
};

export const registerUser = async (
  email: string,
  password: string,
  name?: string,
): Promise<{ user: AuthUser }> => {
  const normalizedEmail = email.trim().toLowerCase();
  const trimmedName = name?.trim() || null;

  const existingUser = await findUserByEmail(normalizedEmail);

  if (existingUser) {
    throw new AuthServiceError('User already exists', 409);
  }

  const passwordHash = await hashPassword(password);
  const user = await createUser(normalizedEmail, passwordHash, trimmedName);

  return {
    user: sanitizeUser(user),
  };
};

export const loginUser = async (
  email: string,
  password: string,
): Promise<AuthResponse> => {
  const normalizedEmail = email.trim().toLowerCase();
  const user = await findUserByEmail(normalizedEmail);

  if (!user) {
    throw new AuthServiceError('Invalid email or password', 401);
  }

  const isPasswordValid = await comparePassword(password, user.passwordHash);

  if (!isPasswordValid) {
    throw new AuthServiceError('Invalid email or password', 401);
  }

  const tokens = await buildTokens(user);

  return {
    user: sanitizeUser(user),
    ...tokens,
  };
};

export const refreshAccessToken = async (
  refreshToken: string,
): Promise<{ accessToken: string }> => {
  const decodedToken = verifyToken(refreshToken, config.jwt.refreshSecret);
  const refreshTokenHash = getTokenHash(refreshToken);
  const storedRefreshToken = await findRefreshToken(refreshTokenHash);

  if (!storedRefreshToken) {
    throw new AuthServiceError('Refresh token not found', 401);
  }

  if (storedRefreshToken.revokedAt) {
    throw new AuthServiceError('Refresh token has been revoked', 401);
  }

  if (storedRefreshToken.expiresAt.getTime() <= Date.now()) {
    throw new AuthServiceError('Refresh token has expired', 401);
  }

  if (storedRefreshToken.userId !== decodedToken.userId) {
    throw new AuthServiceError('Refresh token is invalid', 401);
  }

  const user = await findUserById(decodedToken.userId);

  if (!user) {
    throw new AuthServiceError('User not found', 404);
  }

      return {
        accessToken: signAccessToken({
          userId: user.id,
          email: user.email,
          isAdmin: user.isAdmin,
        }),
      };
};

export const logoutUser = async (refreshToken: string): Promise<void> => {
  const refreshTokenHash = getTokenHash(refreshToken);
  await revokeRefreshToken(refreshTokenHash);
};

const DEFAULT_ADMIN_PASSWORD = 'Admin@12345';

export const ensureAdminUser = async (): Promise<void> => {
  const passwordHash = await hashPassword(DEFAULT_ADMIN_PASSWORD);
  await ensureAdminUserRecord(passwordHash);
};
