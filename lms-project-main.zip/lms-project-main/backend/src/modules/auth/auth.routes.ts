import { Router } from 'express';

import { authenticate } from '../../middleware/authenticate';
import { validateBody } from '../../middleware/validation/validateBody';
import { login, logout, me, refresh, register } from './auth.controller';
import {
  loginSchema,
  refreshTokenSchema,
  registerSchema,
} from './auth.schemas';

const authRoutes = Router();

authRoutes.post('/register', validateBody(registerSchema), register);
authRoutes.post('/login', validateBody(loginSchema), login);
authRoutes.post('/refresh', validateBody(refreshTokenSchema), refresh);
authRoutes.post('/logout', validateBody(refreshTokenSchema), logout);
authRoutes.get('/me', authenticate, me);

export { authRoutes };
