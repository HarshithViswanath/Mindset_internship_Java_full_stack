import type { Request, Response } from 'express';

import { error as errorResponse, success } from '../../utils/apiResponse';
import type {
  LoginBody,
  RefreshTokenBody,
  RegisterBody,
} from './auth.schemas';
import {
  AuthServiceError,
  loginUser,
  logoutUser,
  refreshAccessToken,
  registerUser,
} from './auth.service';

type AuthenticatedRequest = Request & {
  user?: {
    id: number;
    email: string;
    is_admin: boolean;
  };
};

const getErrorResponse = (error: unknown): { statusCode: number; message: string } => {
  if (error instanceof AuthServiceError) {
    return {
      statusCode: error.statusCode,
      message: error.message,
    };
  }

  return {
    statusCode: 500,
    message: 'Internal Server Error',
  };
};

export const register = async (
  req: Request<unknown, unknown, RegisterBody>,
  res: Response,
): Promise<void> => {
  try {
    const { email, password, name } = req.body;
    const result = await registerUser(email, password, name);
    success(res, result, 201);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const login = async (
  req: Request<unknown, unknown, LoginBody>,
  res: Response,
): Promise<void> => {
  try {
    const { email, password } = req.body;
    const result = await loginUser(email, password);
    success(res, result);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const refresh = async (
  req: Request<unknown, unknown, RefreshTokenBody>,
  res: Response,
): Promise<void> => {
  try {
    const { refreshToken } = req.body;
    const result = await refreshAccessToken(refreshToken);
    success(res, result);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const logout = async (
  req: Request<unknown, unknown, RefreshTokenBody>,
  res: Response,
): Promise<void> => {
  try {
    const { refreshToken } = req.body;
    await logoutUser(refreshToken);
    success(res, {
      message: 'Logged out successfully',
    });
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const me = async (
  req: AuthenticatedRequest,
  res: Response,
): Promise<void> => {
  if (!req.user) {
    errorResponse(res, 'Unauthorized', 401);
    return;
  }

  success(res, req.user);
};
