import { getSubjectById } from '../subjects/subject.repository';
import {
  checkEnrollment,
  createEnrollment,
  getUserEnrollments,
  type UserEnrollment,
} from './enrollment.repository';

export class EnrollmentServiceError extends Error {
  public readonly statusCode: number;

  public constructor(message: string, statusCode: number) {
    super(message);
    this.name = 'EnrollmentServiceError';
    this.statusCode = statusCode;
  }
}

export const enrollUserInSubject = async (
  userId: number,
  subjectId: number,
): Promise<{ message: string }> => {
  const subject = await getSubjectById(subjectId);

  if (!subject) {
    throw new EnrollmentServiceError('Subject not found', 404);
  }

  const isAlreadyEnrolled = await checkEnrollment(userId, subjectId);

  if (isAlreadyEnrolled) {
    throw new EnrollmentServiceError('User already enrolled', 409);
  }

  await createEnrollment(userId, subjectId);

  return {
    message: 'Enrolled successfully',
  };
};

export const listUserEnrollments = async (
  userId: number,
): Promise<UserEnrollment[]> => {
  return getUserEnrollments(userId);
};
