import type { Request, Response } from 'express';

import { error as errorResponse, success } from '../../utils/apiResponse';
import {
  enrollUserInSubject,
  EnrollmentServiceError,
  listUserEnrollments,
} from './enrollment.service';

type SubjectParams = {
  subjectId: string;
};

interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    email: string;
    is_admin: boolean;
  };
}

const parsePositiveInteger = (value: string, fieldName: string): number => {
  const parsedValue = Number(value);

  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    throw new EnrollmentServiceError(`Invalid ${fieldName}`, 400);
  }

  return parsedValue;
};

const getAuthenticatedUserId = (req: AuthenticatedRequest): number => {
  const userId = Number(req.user?.id);

  if (!Number.isInteger(userId) || userId <= 0) {
    throw new EnrollmentServiceError('Unauthorized', 401);
  }

  return userId;
};

const getErrorResponse = (error: unknown): { statusCode: number; message: string } => {
  if (error instanceof EnrollmentServiceError) {
    return {
      statusCode: error.statusCode,
      message: error.message,
    };
  }

  return {
    statusCode: 500,
    message: 'Internal Server Error',
  };
};

export const enroll = async (
  req: AuthenticatedRequest & Request<SubjectParams>,
  res: Response,
): Promise<void> => {
  try {
    const userId = getAuthenticatedUserId(req);
    const subjectId = parsePositiveInteger(req.params.subjectId, 'subjectId');
    const result = await enrollUserInSubject(userId, subjectId);

    success(res, result, 201);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const listMine = async (
  req: AuthenticatedRequest,
  res: Response,
): Promise<void> => {
  try {
    const userId = getAuthenticatedUserId(req);
    const enrollments = await listUserEnrollments(userId);

    success(res, enrollments);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};
