import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';

import { pool } from '../../config/db';

export type UserEnrollment = {
  subject_id: number;
  title: string | null;
  slug: string | null;
};

type EnrollmentRow = RowDataPacket & {
  subject_id: number;
  title: string | null;
  slug: string | null;
};

type EnrollmentCheckRow = RowDataPacket & {
  id: number;
};

export const createEnrollment = async (
  userId: number,
  subjectId: number,
): Promise<void> => {
  await pool.execute<ResultSetHeader>(
    `
      INSERT INTO enrollments (user_id, subject_id)
      VALUES (?, ?)
    `,
    [userId, subjectId],
  );
};

export const getUserEnrollments = async (
  userId: number,
): Promise<UserEnrollment[]> => {
  const [rows] = await pool.execute<EnrollmentRow[]>(
    `
      SELECT
        e.subject_id,
        s.title,
        s.slug
      FROM enrollments e
      INNER JOIN subjects s ON s.id = e.subject_id
      WHERE e.user_id = ?
      ORDER BY e.created_at DESC, e.id DESC
    `,
    [userId],
  );

  return rows.map((row) => ({
    subject_id: row.subject_id,
    title: row.title,
    slug: row.slug,
  }));
};

export const checkEnrollment = async (
  userId: number,
  subjectId: number,
): Promise<boolean> => {
  const [rows] = await pool.execute<EnrollmentCheckRow[]>(
    `
      SELECT id
      FROM enrollments
      WHERE user_id = ? AND subject_id = ?
      LIMIT 1
    `,
    [userId, subjectId],
  );

  return rows.length > 0;
};
