import { Router } from 'express';

import { authenticate } from '../../middleware/authenticate';
import { enroll, listMine } from './enrollment.controller';

const enrollmentRoutes = Router();

enrollmentRoutes.post('/subjects/:subjectId/enroll', authenticate, enroll);
enrollmentRoutes.get('/users/me/enrollments', authenticate, listMine);

export { enrollmentRoutes };
