import type { Request, Response } from 'express';

import { error as errorResponse, success } from '../../utils/apiResponse';
import {
  createVideoRecord,
  getFirstUnlockedVideo,
  getVideoWithNavigation,
  VideoServiceError,
} from './video.service';
import type { CreateVideoBody } from './video.schemas';

type VideoParams = {
  videoId: string;
};

type SubjectParams = {
  subjectId: string;
};

type SectionParams = {
  sectionId: string;
};

interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    email: string;
    is_admin: boolean;
  };
}

const parsePositiveInteger = (value: string, fieldName: string): number => {
  const parsedValue = Number(value);

  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    throw new VideoServiceError(`Invalid ${fieldName}`, 400);
  }

  return parsedValue;
};

const getErrorResponse = (error: unknown): { statusCode: number; message: string } => {
  if (error instanceof VideoServiceError) {
    return {
      statusCode: error.statusCode,
      message: error.message,
    };
  }

  return {
    statusCode: 500,
    message: 'Internal Server Error',
  };
};

export const getById = async (
  req: AuthenticatedRequest & Request<VideoParams>,
  res: Response,
): Promise<void> => {
  try {
    const videoId = parsePositiveInteger(req.params.videoId, 'videoId');
    const userId = req.user?.id ?? null;
    const video = await getVideoWithNavigation(videoId, userId);

    success(res, video);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const getFirstBySubject = async (
  req: AuthenticatedRequest & Request<SubjectParams>,
  res: Response,
): Promise<void> => {
  try {
    const subjectId = parsePositiveInteger(req.params.subjectId, 'subjectId');
    const userId = Number(req.user?.id);

    if (!Number.isInteger(userId) || userId <= 0) {
      throw new VideoServiceError('Unauthorized', 401);
    }

    const firstVideo = await getFirstUnlockedVideo(userId, subjectId);

    success(res, firstVideo);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};

export const createBySection = async (
  req: Request<SectionParams, unknown, CreateVideoBody>,
  res: Response,
): Promise<void> => {
  try {
    const sectionId = parsePositiveInteger(req.params.sectionId, 'sectionId');
    const { title, description, youtubeUrl, orderIndex, durationSeconds } = req.body;
    const video = await createVideoRecord(
      sectionId,
      title,
      description ?? null,
      youtubeUrl,
      orderIndex,
      durationSeconds ?? null,
    );

    success(res, video, 201);
  } catch (error) {
    const { statusCode, message } = getErrorResponse(error);
    errorResponse(res, message, statusCode);
  }
};
