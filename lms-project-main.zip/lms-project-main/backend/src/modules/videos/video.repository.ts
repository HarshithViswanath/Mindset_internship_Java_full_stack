import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';

import { pool } from '../../config/db';

export type VideoRecord = {
  id: number;
  title: string | null;
  description: string | null;
  youtube_url: string | null;
  order_index: number | null;
  duration_seconds: number | null;
  section_id: number;
  subject_id: number;
};

export type SubjectVideoSequenceItem = {
  id: number;
  subject_id: number;
  section_id: number;
  title: string | null;
  order_index: number | null;
};

export type CreatedVideo = {
  id: number;
  sectionId: number;
  title: string | null;
  description: string | null;
  youtubeUrl: string | null;
  orderIndex: number | null;
  durationSeconds: number | null;
};

export type SectionRecord = {
  id: number;
  subjectId: number;
  title: string | null;
  orderIndex: number | null;
};

type VideoRow = RowDataPacket & {
  id: number;
  title: string | null;
  description: string | null;
  youtube_url: string | null;
  order_index: number | null;
  duration_seconds: number | null;
  section_id: number;
  subject_id: number;
};

type SubjectVideoSequenceRow = RowDataPacket & {
  id: number;
  subject_id: number;
  section_id: number;
  title: string | null;
  order_index: number | null;
};

type CreatedVideoRow = RowDataPacket & {
  id: number;
  section_id: number;
  title: string | null;
  description: string | null;
  youtube_url: string | null;
  order_index: number | null;
  duration_seconds: number | null;
};

type SectionRow = RowDataPacket & {
  id: number;
  subject_id: number;
  title: string | null;
  order_index: number | null;
};

const mapVideo = (row: VideoRow): VideoRecord => {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    youtube_url: row.youtube_url,
    order_index: row.order_index,
    duration_seconds: row.duration_seconds,
    section_id: row.section_id,
    subject_id: row.subject_id,
  };
};

const mapSequenceItem = (
  row: SubjectVideoSequenceRow,
): SubjectVideoSequenceItem => {
  return {
    id: row.id,
    subject_id: row.subject_id,
    section_id: row.section_id,
    title: row.title,
    order_index: row.order_index,
  };
};

export const getVideoById = async (videoId: number): Promise<VideoRecord | null> => {
  const [rows] = await pool.execute<VideoRow[]>(
    `
      SELECT
        v.id,
        v.title,
        v.description,
        v.youtube_url,
        v.order_index,
        v.duration_seconds,
        v.section_id,
        sec.subject_id
      FROM videos v
      INNER JOIN sections sec ON sec.id = v.section_id
      WHERE v.id = ?
      LIMIT 1
    `,
    [videoId],
  );

  const video = rows[0];

  return video ? mapVideo(video) : null;
};

export const getSubjectVideoSequence = async (
  subjectId: number,
): Promise<SubjectVideoSequenceItem[]> => {
  const [rows] = await pool.execute<SubjectVideoSequenceRow[]>(
    `
      SELECT
        v.id,
        sec.subject_id,
        v.section_id,
        v.title,
        v.order_index
      FROM subjects s
      INNER JOIN sections sec ON sec.subject_id = s.id
      INNER JOIN videos v ON v.section_id = sec.id
      WHERE s.id = ?
      ORDER BY sec.order_index ASC, sec.id ASC, v.order_index ASC, v.id ASC
    `,
    [subjectId],
  );

  return rows.map(mapSequenceItem);
};

export const getFirstVideo = async (
  subjectId: number,
): Promise<SubjectVideoSequenceItem | null> => {
  const [rows] = await pool.execute<SubjectVideoSequenceRow[]>(
    `
      SELECT
        v.id,
        sec.subject_id,
        v.section_id,
        v.title,
        v.order_index
      FROM subjects s
      INNER JOIN sections sec ON sec.subject_id = s.id
      INNER JOIN videos v ON v.section_id = sec.id
      WHERE s.id = ?
      ORDER BY sec.order_index ASC, sec.id ASC, v.order_index ASC, v.id ASC
      LIMIT 1
    `,
    [subjectId],
  );

  const firstVideo = rows[0];

  return firstVideo ? mapSequenceItem(firstVideo) : null;
};

export const createVideo = async (
  sectionId: number,
  title: string,
  description: string | null,
  youtubeUrl: string,
  orderIndex: number,
  durationSeconds: number | null,
): Promise<CreatedVideo> => {
  const [result] = await pool.execute<ResultSetHeader>(
    `
      INSERT INTO videos (
        section_id,
        title,
        description,
        youtube_url,
        order_index,
        duration_seconds
      )
      VALUES (?, ?, ?, ?, ?, ?)
    `,
    [sectionId, title, description, youtubeUrl, orderIndex, durationSeconds],
  );

  const [rows] = await pool.execute<CreatedVideoRow[]>(
    `
      SELECT
        id,
        section_id,
        title,
        description,
        youtube_url,
        order_index,
        duration_seconds
      FROM videos
      WHERE id = ?
      LIMIT 1
    `,
    [result.insertId],
  );

  const video = rows[0];

  if (!video) {
    throw new Error('Failed to load created video');
  }

  return {
    id: video.id,
    sectionId: video.section_id,
    title: video.title,
    description: video.description,
    youtubeUrl: video.youtube_url,
    orderIndex: video.order_index,
    durationSeconds: video.duration_seconds,
  };
};

export const getSectionById = async (
  sectionId: number,
): Promise<SectionRecord | null> => {
  const [rows] = await pool.execute<SectionRow[]>(
    `
      SELECT id, subject_id, title, order_index
      FROM sections
      WHERE id = ?
      LIMIT 1
    `,
    [sectionId],
  );

  const section = rows[0];

  if (!section) {
    return null;
  }

  return {
    id: section.id,
    subjectId: section.subject_id,
    title: section.title,
    orderIndex: section.order_index,
  };
};
