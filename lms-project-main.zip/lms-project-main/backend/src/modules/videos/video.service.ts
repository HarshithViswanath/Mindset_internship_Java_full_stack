import {
  createVideo,
  getSectionById,
  getSubjectVideoSequence,
  getVideoById,
  type CreatedVideo,
} from './video.repository';
import { getVideoProgress } from '../progress/progress.repository';
import { isVideoLocked } from '../../utils/ordering';

export class VideoServiceError extends Error {
  public readonly statusCode: number;

  public constructor(message: string, statusCode: number) {
    super(message);
    this.name = 'VideoServiceError';
    this.statusCode = statusCode;
  }
}

export type VideoNavigation = {
  id: number;
  title: string | null;
  youtube_url: string | null;
  previous_video_id: number | null;
  next_video_id: number | null;
  locked: boolean;
  unlock_reason?: string;
};

export const getVideoWithNavigation = async (
  videoId: number,
  userId: number | null,
): Promise<VideoNavigation> => {
  const video = await getVideoById(videoId);

  if (!video) {
    throw new VideoServiceError('Video not found', 404);
  }

  const subjectVideoSequence = await getSubjectVideoSequence(video.subject_id);
  const currentVideoIndex = subjectVideoSequence.findIndex(
    (subjectVideo) => subjectVideo.id === video.id,
  );

  if (currentVideoIndex === -1) {
    throw new VideoServiceError('Video sequence not found', 404);
  }

  const previousVideo = subjectVideoSequence[currentVideoIndex - 1] ?? null;
  const nextVideo = subjectVideoSequence[currentVideoIndex + 1] ?? null;
  const lockState = await isVideoLocked(userId, video.id);

  return {
    id: video.id,
    title: video.title,
    youtube_url: video.youtube_url,
    previous_video_id: previousVideo?.id ?? null,
    next_video_id: nextVideo?.id ?? null,
    locked: lockState.locked,
    ...(lockState.unlock_reason
      ? { unlock_reason: lockState.unlock_reason }
      : {}),
  };
};

export const getFirstUnlockedVideo = async (
  userId: number,
  subjectId: number,
): Promise<{ video_id: number }> => {
  const subjectVideoSequence = await getSubjectVideoSequence(subjectId);

  if (subjectVideoSequence.length === 0) {
    throw new VideoServiceError('No videos found for subject', 404);
  }

  for (const video of subjectVideoSequence) {
    const progress = await getVideoProgress(userId, video.id);

    if (!progress.is_completed) {
      return {
        video_id: video.id,
      };
    }
  }

  const lastVideo = subjectVideoSequence[subjectVideoSequence.length - 1];

  if (!lastVideo) {
    throw new VideoServiceError('No videos found for subject', 404);
  }

  return {
    video_id: lastVideo.id,
  };
};

export const createVideoRecord = async (
  sectionId: number,
  title: string,
  description: string | null,
  youtubeUrl: string,
  orderIndex: number,
  durationSeconds: number | null,
): Promise<CreatedVideo> => {
  const section = await getSectionById(sectionId);

  if (!section) {
    throw new VideoServiceError('Section not found', 404);
  }

  return createVideo(
    sectionId,
    title,
    description,
    youtubeUrl,
    orderIndex,
    durationSeconds,
  );
};
