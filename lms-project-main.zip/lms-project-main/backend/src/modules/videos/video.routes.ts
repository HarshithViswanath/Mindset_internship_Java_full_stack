import { Router } from 'express';

import { authenticate } from '../../middleware/authenticate';
import { requireAdmin } from '../../middleware/requireAdmin';
import { validateBody } from '../../middleware/validation/validateBody';
import {
  requireSubjectEnrollment,
  requireVideoEnrollment,
} from '../../middleware/requireEnrollment';
import {
  createBySection,
  getById,
  getFirstBySubject,
} from './video.controller';
import { createVideoSchema } from './video.schemas';

const videoRoutes = Router();
const subjectVideoRoutes = Router();

videoRoutes.get('/:videoId', authenticate, requireVideoEnrollment, getById);
subjectVideoRoutes.post(
  '/sections/:sectionId/videos',
  authenticate,
  requireAdmin,
  validateBody(createVideoSchema),
  createBySection,
);
subjectVideoRoutes.get(
  '/subjects/:subjectId/first-video',
  authenticate,
  requireSubjectEnrollment,
  getFirstBySubject,
);

export { subjectVideoRoutes, videoRoutes };
