import { z } from 'zod';

export const createVideoSchema = z.object({
  title: z.string().trim().min(1).max(255),
  description: z.string().trim().max(5000).nullable().optional(),
  youtubeUrl: z.string().trim().url().max(500),
  orderIndex: z.number().int().min(1),
  durationSeconds: z.number().int().min(0).nullable().optional(),
});

export type CreateVideoBody = z.infer<typeof createVideoSchema>;
