import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';

import { errorHandler } from './middleware/errorHandler';
import { requestLogger } from './middleware/requestLogger';
import { authRoutes } from './modules/auth/auth.routes';
import { enrollmentRoutes } from './modules/enrollments/enrollment.routes';
import { healthRouter } from './modules/health/health.routes';
import { progressRoutes } from './modules/progress/progress.routes';
import { subjectRoutes } from './modules/subjects/subject.routes';
import {
  subjectVideoRoutes,
  videoRoutes,
} from './modules/videos/video.routes';

const app = express();

app.use(helmet());
app.use(morgan('combined'));
app.use(requestLogger);
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api', enrollmentRoutes);
app.use('/api/progress', progressRoutes);
app.use('/api/subjects', subjectRoutes);
app.use('/api/videos', videoRoutes);
app.use('/api', subjectVideoRoutes);
app.use('/api', healthRouter);

app.use(errorHandler);

export { app };
