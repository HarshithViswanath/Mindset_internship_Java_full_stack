import jwt, { type JwtPayload, type SignOptions } from 'jsonwebtoken';

import { config } from '../config/env';

export type AuthTokenPayload = {
  userId: number;
  email: string;
  isAdmin?: boolean;
};

const signToken = (
  payload: AuthTokenPayload,
  secret: string,
  expiresIn: NonNullable<SignOptions['expiresIn']>,
): string => {
  return jwt.sign(payload, secret, { expiresIn });
};

export const signAccessToken = (payload: AuthTokenPayload): string => {
  return signToken(payload, config.jwt.accessSecret, '15m');
};

export const signRefreshToken = (payload: AuthTokenPayload): string => {
  return signToken(payload, config.jwt.refreshSecret, '30d');
};

export const verifyToken = (
  token: string,
  secret: string = config.jwt.accessSecret,
): JwtPayload & AuthTokenPayload => {
  const decodedToken = jwt.verify(token, secret);

  if (typeof decodedToken === 'string') {
    throw new Error('Invalid token payload');
  }

  return decodedToken as JwtPayload & AuthTokenPayload;
};
