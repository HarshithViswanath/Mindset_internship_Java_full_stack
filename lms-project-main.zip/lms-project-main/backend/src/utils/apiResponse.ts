import type { Response } from 'express';

export const success = <T>(res: Response, data: T, statusCode = 200): void => {
  res.status(statusCode).json({
    success: true,
    data,
  });
};

export const error = (
  res: Response,
  message: string,
  statusCode = 500,
): void => {
  res.status(statusCode).json({
    success: false,
    message,
  });
};
