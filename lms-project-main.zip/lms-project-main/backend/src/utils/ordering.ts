import {
  getVideoProgress,
} from '../modules/progress/progress.repository';
import {
  getSubjectVideoSequence,
  getVideoById,
  type SubjectVideoSequenceItem,
} from '../modules/videos/video.repository';

export type OrderedSubjectVideo = {
  video_id: number;
  section_id: number;
};

export type VideoLockState = {
  locked: boolean;
  unlock_reason?: string;
};

export const getOrderedSubjectVideos = async (
  subjectId: number,
): Promise<OrderedSubjectVideo[]> => {
  const videos = await getSubjectVideoSequence(subjectId);

  return videos.map((video) => ({
    video_id: video.id,
    section_id: video.section_id,
  }));
};

export const findPreviousVideo = async (
  videoId: number,
): Promise<OrderedSubjectVideo | null> => {
  const video = await getVideoById(videoId);

  if (!video) {
    return null;
  }

  const orderedVideos = await getOrderedSubjectVideos(video.subject_id);
  const currentVideoIndex = orderedVideos.findIndex(
    (orderedVideo) => orderedVideo.video_id === videoId,
  );

  if (currentVideoIndex <= 0) {
    return null;
  }

  return orderedVideos[currentVideoIndex - 1] ?? null;
};

export const isVideoLocked = async (
  userId: number | null,
  videoId: number,
): Promise<VideoLockState> => {
  const previousVideo = await findPreviousVideo(videoId);

  if (!previousVideo) {
    return { locked: false };
  }

  if (userId === null) {
    return {
      locked: true,
      unlock_reason: 'Complete previous video',
    };
  }

  const previousVideoProgress = await getVideoProgress(
    userId,
    previousVideo.video_id,
  );

  if (previousVideoProgress.is_completed) {
    return { locked: false };
  }

  return {
    locked: true,
    unlock_reason: 'Complete previous video',
  };
};

export const buildVideoLockMap = async (
  userId: number | null,
  sequence: SubjectVideoSequenceItem[],
): Promise<Map<number, VideoLockState>> => {
  const videoLockMap = new Map<number, VideoLockState>();

  for (let index = 0; index < sequence.length; index += 1) {
    const currentVideo = sequence[index];

    if (!currentVideo) {
      continue;
    }

    const previousVideo = sequence[index - 1];

    if (!previousVideo) {
      videoLockMap.set(currentVideo.id, { locked: false });
      continue;
    }

    if (userId === null) {
      videoLockMap.set(currentVideo.id, {
        locked: true,
        unlock_reason: 'Complete previous video',
      });
      continue;
    }

    const previousVideoProgress = await getVideoProgress(userId, previousVideo.id);

    if (previousVideoProgress.is_completed) {
      videoLockMap.set(currentVideo.id, { locked: false });
      continue;
    }

    videoLockMap.set(currentVideo.id, {
      locked: true,
      unlock_reason: 'Complete previous video',
    });
  }

  return videoLockMap;
};
