import { readFile } from 'node:fs/promises';
import path from 'node:path';

import { pool } from '../config/db';

const schemaFilePath = path.resolve(__dirname, 'schema.sql');

const runMigration = async (): Promise<void> => {
  try {
    const schemaSql = await readFile(schemaFilePath, 'utf-8');
    const statements = schemaSql
      .split(/;\s*(?:\r?\n|$)/)
      .map((statement) => statement.trim())
      .filter((statement) => statement.length > 0);

    for (const statement of statements) {
      await pool.query(statement);
    }

    console.log('Database schema created successfully');
  } catch (error) {
    console.error('Database migration failed', error);
    throw error;
  } finally {
    await pool.end();
  }
};

void runMigration();
