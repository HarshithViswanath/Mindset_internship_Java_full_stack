import mysql from 'mysql2/promise';

import { config } from './env';

export const pool = mysql.createPool({
  host: config.db.host,
  port: config.db.port,
  user: config.db.user,
  password: config.db.password,
  database: config.db.database,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

export const testDbConnection = async (): Promise<void> => {
  try {
    await pool.query('SELECT 1');
    console.log('Database connected successfully');
  } catch (error) {
    console.error('Database connection failed', {
      host: config.db.host,
      port: config.db.port,
      user: config.db.user,
      database: config.db.database,
      error,
    });
    throw error;
  }
};
