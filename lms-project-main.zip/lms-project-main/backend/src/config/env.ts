import dotenv from 'dotenv';

dotenv.config();

const parseNumber = (value: string | undefined, fallback: number): number => {
  if (!value) {
    return fallback;
  }

  const parsedValue = Number(value);

  if (Number.isNaN(parsedValue)) {
    throw new Error(`Invalid numeric environment value: "${value}"`);
  }

  return parsedValue;
};

const getRequiredEnv = (name: string): string => {
  const value = process.env[name]?.trim();

  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }

  return value;
};

const dbHost = getRequiredEnv('DB_HOST');
const dbUser = getRequiredEnv('DB_USER');
const dbName = getRequiredEnv('DB_NAME');
const jwtAccessSecret = getRequiredEnv('JWT_ACCESS_SECRET');
const jwtRefreshSecret = getRequiredEnv('JWT_REFRESH_SECRET');

console.log('Environment validation', {
  DB_HOST: dbHost,
  DB_USER: dbUser,
  DB_NAME: dbName,
});

export const config = {
  port: parseNumber(process.env.PORT, 3000),
  db: {
    host: dbHost,
    port: parseNumber(process.env.DB_PORT, 3306),
    user: dbUser,
    password: process.env.DB_PASSWORD ?? '',
    database: dbName,
  },
  jwt: {
    accessSecret: jwtAccessSecret,
    refreshSecret: jwtRefreshSecret,
  },
} as const;
