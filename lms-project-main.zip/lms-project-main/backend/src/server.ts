import { app } from './app';
import { testDbConnection } from './config/db';
import { config } from './config/env';
import { ensureAdminUser } from './modules/auth/auth.service';

const startServer = async (): Promise<void> => {
  try {
    await testDbConnection();
    await ensureAdminUser();
  } catch (error) {
    console.error('Startup database check failed', error);
    process.exit(1);
  }

  app.listen(config.port, () => {
    console.log(`Server is running on port ${config.port}`);
  });
};

void startServer();
