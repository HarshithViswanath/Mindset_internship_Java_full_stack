import type { NextFunction, Request, Response } from 'express';

import { verifyToken } from '../utils/jwt';
import { error } from '../utils/apiResponse';

interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    email: string;
    is_admin: boolean;
  };
}

export const authenticate = (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): void => {
  const authorizationHeader = req.headers.authorization;

  if (!authorizationHeader?.startsWith('Bearer ')) {
    error(res, 'Authorization token is required', 401);
    return;
  }

  const token = authorizationHeader.slice('Bearer '.length).trim();

  if (!token) {
    error(res, 'Authorization token is required', 401);
    return;
  }

  try {
    const decodedToken = verifyToken(token);
    req.user = {
      id: decodedToken.userId,
      email: decodedToken.email,
      is_admin: Boolean(decodedToken.isAdmin),
    };
    next();
  } catch (_error) {
    error(res, 'Invalid authorization token', 401);
  }
};
