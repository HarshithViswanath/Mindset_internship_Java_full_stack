import type { NextFunction, Request, Response } from 'express';

import { error } from '../utils/apiResponse';
import { checkEnrollment } from '../modules/enrollments/enrollment.repository';
import { getSubjectById } from '../modules/subjects/subject.repository';
import { getVideoById } from '../modules/videos/video.repository';

type AuthenticatedRequest = Request & {
  user?: {
    id: number;
    email: string;
  };
};

const parsePositiveInteger = (value: string | string[] | undefined): number | null => {
  if (!value || Array.isArray(value)) {
    return null;
  }

  const parsedValue = Number(value);

  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    return null;
  }

  return parsedValue;
};

export const requireSubjectEnrollment = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  const userId = req.user?.id;
  const subjectId = parsePositiveInteger(req.params.subjectId);

  if (!userId) {
    error(res, 'Unauthorized', 401);
    return;
  }

  if (!subjectId) {
    error(res, 'Invalid subjectId', 400);
    return;
  }

  const subject = await getSubjectById(subjectId);

  if (!subject) {
    error(res, 'Subject not found', 404);
    return;
  }

  const enrolled = await checkEnrollment(userId, subjectId);

  if (!enrolled) {
    error(res, 'Enrollment required', 403);
    return;
  }

  next();
};

export const requireVideoEnrollment = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  const userId = req.user?.id;
  const videoId = parsePositiveInteger(req.params.videoId);

  if (!userId) {
    error(res, 'Unauthorized', 401);
    return;
  }

  if (!videoId) {
    error(res, 'Invalid videoId', 400);
    return;
  }

  const video = await getVideoById(videoId);

  if (!video) {
    error(res, 'Video not found', 404);
    return;
  }

  const enrolled = await checkEnrollment(userId, video.subject_id);

  if (!enrolled) {
    error(res, 'Enrollment required', 403);
    return;
  }

  next();
};
