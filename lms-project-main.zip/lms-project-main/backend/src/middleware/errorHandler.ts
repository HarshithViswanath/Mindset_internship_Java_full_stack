import type { NextFunction, Request, Response } from 'express';
import { JsonWebTokenError, TokenExpiredError } from 'jsonwebtoken';
import { ZodError } from 'zod';

import { error as errorResponse } from '../utils/apiResponse';

type DatabaseError = Error & {
  code?: string;
};

export const errorHandler = (
  error: Error,
  _req: Request,
  res: Response,
  _next: NextFunction,
): void => {
  console.error(error);

  if (error instanceof ZodError) {
    errorResponse(
      res,
      error.issues.map((issue) => issue.message).join(', '),
      400,
    );
    return;
  }

  if (error instanceof TokenExpiredError) {
    errorResponse(res, 'Token expired', 401);
    return;
  }

  if (error instanceof JsonWebTokenError) {
    errorResponse(res, 'Invalid token', 401);
    return;
  }

  const databaseError = error as DatabaseError;

  if (databaseError.code === 'ER_DUP_ENTRY') {
    errorResponse(res, 'Duplicate record', 409);
    return;
  }

  if (databaseError.code === 'ER_NO_REFERENCED_ROW_2') {
    errorResponse(res, 'Referenced record not found', 400);
    return;
  }

  if (databaseError.code === 'ER_BAD_NULL_ERROR') {
    errorResponse(res, 'Missing required database field', 400);
    return;
  }

  errorResponse(res, error.message || 'Internal Server Error', 500);
};
