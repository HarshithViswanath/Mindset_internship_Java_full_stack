import type { NextFunction, Request, Response } from 'express';

import { error } from '../utils/apiResponse';

type AdminRequest = Request & {
  user?: {
    id: number;
    email: string;
    is_admin?: boolean;
  };
};

export const requireAdmin = (
  req: AdminRequest,
  res: Response,
  next: NextFunction,
): void => {
  if (!req.user) {
    error(res, 'Unauthorized', 401);
    return;
  }

  if (!req.user.is_admin) {
    error(res, 'Admin access required', 403);
    return;
  }

  next();
};
