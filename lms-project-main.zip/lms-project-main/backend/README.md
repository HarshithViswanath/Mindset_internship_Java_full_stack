# LMS Backend

Production-ready Learning Management System backend.

## Features

- JWT Authentication (Access + Refresh Tokens)
- Subjects / Courses
- Sections & Videos
- Strict Learning Order (locking system)
- Progress Tracking
- Resume Learning
- Enrollment System

## Tech Stack

- Node.js
- Express
- TypeScript
- MySQL

## Run Locally

```bash
npm install
npm run dev