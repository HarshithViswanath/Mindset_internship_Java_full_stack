'use client'

import { useState } from 'react'
import { Header } from './Header'
import { Sidebar, type Section } from './Sidebar'

interface AppLayoutProps {
  sections: Section[]
  activeVideoId?: string
  onVideoClick?: (videoId: string) => void
  children?: React.ReactNode
}

export function AppLayout({
  sections,
  activeVideoId,
  onVideoClick,
  children,
}: AppLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)

  return (
    <div className="flex flex-col h-screen bg-background">
      <Header onMenuClick={() => setIsSidebarOpen(true)} />

      <div className="flex flex-1 overflow-hidden pt-16">
        <Sidebar
          sections={sections}
          activeVideoId={activeVideoId}
          onVideoClick={onVideoClick}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />

        <main className="flex-1 overflow-auto">
          <div className="h-full p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full">
            {children || (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <h2 className="text-2xl font-semibold text-foreground mb-2">
                    Select a video to begin
                  </h2>
                  <p className="text-muted-foreground">
                    Choose a course section and video from the sidebar to start learning
                  </p>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}
