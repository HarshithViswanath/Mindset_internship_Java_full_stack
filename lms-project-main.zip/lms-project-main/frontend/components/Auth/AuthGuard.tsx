'use client'

import { useEffect, useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { useAuthStore } from '@/store/authStore'

interface AuthGuardProps {
  children: React.ReactNode
}

/**
 * Wraps protected pages.
 *
 * Flow:
 * 1. On mount → call rehydrate() to load token from localStorage.
 * 2. Set `ready = true` (triggers re-render with current auth state).
 * 3. If not authenticated after rehydration → redirect to /auth/login.
 * 4. Guard against redirecting if already on the login page.
 */
export function AuthGuard({ children }: AuthGuardProps) {
  const router = useRouter()
  const pathname = usePathname()
  const { isAuthenticated, rehydrate } = useAuthStore()
  // `ready` becomes true once rehydration has run — this is reactive (unlike a ref),
  // so the redirect effect fires correctly after rehydration completes.
  const [ready, setReady] = useState(false)

  // Step 1: rehydrate once on mount, then mark ready.
  useEffect(() => {
    rehydrate()
    setReady(true)
  }, [rehydrate])

  // Step 2: once ready, redirect if still not authenticated.
  useEffect(() => {
    if (!ready) return
    if (isAuthenticated) return

    // Safety: never redirect to /auth/login if already there (prevents loops).
    if (pathname.startsWith('/auth')) return

    router.replace(`/auth/login?next=${encodeURIComponent(pathname)}`)
  }, [ready, isAuthenticated, pathname, router])

  // Show spinner while rehydrating OR while redirect is in flight.
  if (!ready || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-5 w-5 animate-spin rounded-full border-2 border-border border-t-foreground" />
      </div>
    )
  }

  return <>{children}</>
}
