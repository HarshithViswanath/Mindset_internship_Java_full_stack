'use client'

import { ChevronDown } from 'lucide-react'
import { useState } from 'react'
import { cn } from '@/lib/utils'
import { VideoItem } from './video-item'

export interface Video {
  id: string
  title: string
  completed?: boolean
  locked?: boolean
}

interface SectionItemProps {
  id: string
  title: string
  videos: Video[]
  activeVideoId?: string
  onVideoClick?: (videoId: string) => void
  defaultExpanded?: boolean
}

export function SectionItem({
  id,
  title,
  videos,
  activeVideoId,
  onVideoClick,
  defaultExpanded = true,
}: SectionItemProps) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded)

  const totalCount = videos.length

  return (
    <div className="space-y-2">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between px-4 py-3 rounded-md hover:bg-muted transition-colors duration-200"
      >
        <div className="flex-1 text-left">
          <h3 className="font-semibold text-sm text-foreground">{title}</h3>
          <p className="text-xs text-muted-foreground mt-1">
            {totalCount} video{totalCount !== 1 ? 's' : ''}
          </p>
        </div>
        <ChevronDown
          className={cn(
            'h-4 w-4 text-muted-foreground transition-transform duration-200',
            isExpanded && 'rotate-180'
          )}
        />
      </button>

      {isExpanded && (
        <div className="space-y-1 pl-2">
          {videos.map((video) => (
            <VideoItem
              key={video.id}
              id={video.id}
              title={video.title}
              completed={video.completed}
              locked={video.locked}
              isActive={
                activeVideoId !== undefined &&
                String(activeVideoId) === String(video.id)
              }
              onClick={onVideoClick}
            />
          ))}
        </div>
      )}
    </div>
  )
}
