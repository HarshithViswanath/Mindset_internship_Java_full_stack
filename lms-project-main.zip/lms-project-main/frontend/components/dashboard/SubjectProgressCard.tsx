'use client'

import Link from 'next/link'
import { ChevronRight } from 'lucide-react'

import type { DashboardSubject } from '@/hooks/useDashboardData'

type SubjectProgressCardProps = {
  subject: DashboardSubject
}

export function SubjectProgressCard({
  subject,
}: SubjectProgressCardProps) {
  return (
    <li className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0 flex-1 space-y-3">
          <div>
            <h3 className="line-clamp-1 text-base font-semibold text-foreground">
              {subject.title}
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              {subject.completedLessons} / {subject.totalLessons} lessons completed
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium text-foreground">
                {subject.progressPercent}%
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-foreground transition-[width]"
                style={{ width: `${subject.progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        <Link
          href={
            subject.nextLessonId != null
              ? `/subjects/${subject.subjectId}/lessons/${subject.nextLessonId}`
              : `/subjects/${subject.subjectId}`
          }
          className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-3 py-2 text-sm transition-colors hover:bg-muted"
        >
          Open
          <ChevronRight className="h-4 w-4" />
        </Link>
      </div>
    </li>
  )
}
