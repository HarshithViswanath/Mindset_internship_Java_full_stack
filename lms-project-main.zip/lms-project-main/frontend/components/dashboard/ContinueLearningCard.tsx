'use client'

import Link from 'next/link'
import { ArrowRight, PlayCircle } from 'lucide-react'

import type { DashboardSubject } from '@/hooks/useDashboardData'

type ContinueLearningCardProps = {
  subject: DashboardSubject
}

export function ContinueLearningCard({
  subject,
}: ContinueLearningCardProps) {
  if (subject.nextLessonId == null) {
    return null
  }

  return (
    <section className="rounded-xl border border-border bg-card p-6 shadow-sm">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
            <PlayCircle className="h-3.5 w-3.5" />
            Continue Learning
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">{subject.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {subject.completedLessons} of {subject.totalLessons} lessons completed
            </p>
          </div>
        </div>

        <Link
          href={`/subjects/${subject.subjectId}/lessons/${subject.nextLessonId}`}
          className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          Resume Learning
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </section>
  )
}
