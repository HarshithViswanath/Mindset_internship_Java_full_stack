'use client'

import { useMemo, useState } from 'react'

import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import type { LessonQuiz as LessonQuizType } from '@/lib/lessonQuiz'

type LessonQuizProps = {
  quiz: LessonQuizType
  onPass: () => void
}

export function LessonQuiz({
  quiz,
  onPass,
}: LessonQuizProps) {
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [feedback, setFeedback] = useState<string | null>(null)
  const [failedAttempt, setFailedAttempt] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const allAnswered = useMemo(
    () => quiz.questions.every((question) => answers[question.id]),
    [answers, quiz.questions],
  )

  function handleAnswer(questionId: string, option: string) {
    setAnswers((current) => ({
      ...current,
      [questionId]: option,
    }))
    setFeedback(null)
    setFailedAttempt(false)
  }

  async function handleSubmit() {
    if (!allAnswered || submitting) {
      return
    }

    setSubmitting(true)

    const correctCount = quiz.questions.reduce((total, question) => {
      return total + (answers[question.id] === question.correctAnswer ? 1 : 0)
    }, 0)

    if (correctCount >= quiz.passingScore) {
      setFeedback(`Passed ${correctCount}/${quiz.questions.length}`)
      setFailedAttempt(false)
      onPass()
      setSubmitting(false)
      return
    }

    setFeedback(
      `You scored ${correctCount}/${quiz.questions.length}. Review the lesson and try again.`,
    )
    setFailedAttempt(true)
    setSubmitting(false)
  }

  function handleRetry() {
    setAnswers({})
    setFeedback(null)
    setFailedAttempt(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{quiz.title}</CardTitle>
        <CardDescription>
          Answer {quiz.passingScore} of {quiz.questions.length} correctly to complete this lesson.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {quiz.questions.map((question, index) => (
          <div key={question.id} className="space-y-3">
            <div>
              <p className="text-sm font-medium text-foreground">
                {index + 1}. {question.question}
              </p>
            </div>

            <div className="space-y-2">
              {question.options.map((option) => {
                const checked = answers[question.id] === option

                return (
                  <label
                    key={option}
                    className="flex cursor-pointer items-start gap-3 rounded-md border border-border bg-background px-3 py-2 text-sm transition-colors hover:bg-muted"
                  >
                    <input
                      type="radio"
                      name={question.id}
                      value={option}
                      checked={checked}
                      onChange={() => handleAnswer(question.id, option)}
                      className="mt-1"
                    />
                    <span>{option}</span>
                  </label>
                )
              })}
            </div>
          </div>
        ))}

        {feedback && (
          <p className="text-sm text-muted-foreground">{feedback}</p>
        )}

        <Button
          type="button"
          onClick={handleSubmit}
          disabled={!allAnswered || submitting}
        >
          Submit Quiz
        </Button>

        {failedAttempt && (
          <Button
            type="button"
            variant="outline"
            onClick={handleRetry}
          >
            Retry Quiz
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
