'use client'

import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Menu, User, LogOut, ChevronDown, BookOpen, LayoutDashboard } from 'lucide-react'

import { Button } from '../ui/button'
import { useAuthStore } from '@/store/authStore'

interface HeaderProps {
  onMenuClick?: () => void
}

export function Header({ onMenuClick }: HeaderProps) {
  const router = useRouter()
  const { user, isAuthenticated, logout, rehydrate } = useAuthStore()
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  // Rehydrate on mount so the header reflects auth state after a page load
  useEffect(() => {
    rehydrate()
  }, [rehydrate])

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  async function handleLogout() {
    setMenuOpen(false)
    await logout()
    router.replace('/auth/login')
  }

  const initials = user
    ? userInitials(user.name ?? user.email)
    : null

  return (
    <header className="fixed top-0 left-0 right-0 h-16 border-b border-border bg-background z-40">
      <div className="flex items-center justify-between h-full px-4 sm:px-6">

        {/* Left: hamburger + brand */}
        <div className="flex items-center gap-3">
          {onMenuClick && (
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={onMenuClick}
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
          )}
          <Link href="/" className="flex items-center gap-2 text-sm font-semibold">
            <BookOpen className="h-4 w-4" />
            LMS
          </Link>
        </div>

        {/* Right: user menu or auth links */}
        <div className="flex items-center gap-2">
          {isAuthenticated && user ? (
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setMenuOpen((v) => !v)}
                className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-muted transition-colors"
                aria-expanded={menuOpen}
                aria-haspopup="true"
              >
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-semibold select-none">
                  {initials}
                </div>
                <span className="hidden sm:block max-w-[120px] truncate text-sm">
                  {user.name ?? user.email}
                </span>
                <ChevronDown className={`h-3.5 w-3.5 text-muted-foreground transition-transform ${menuOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Dropdown */}
              {menuOpen && (
                <div className="absolute right-0 top-full mt-1 w-52 rounded-md border border-border bg-background shadow-lg py-1 z-50">
                  {/* User info */}
                  <div className="px-3 py-2 border-b border-border">
                    <p className="text-xs font-medium truncate">{user.name ?? 'Account'}</p>
                    <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                  </div>

                  {/* Profile link */}
                  <Link
                    href="/dashboard"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted transition-colors"
                  >
                    <LayoutDashboard className="h-3.5 w-3.5 text-muted-foreground" />
                    Dashboard
                  </Link>

                  <Link
                    href="/profile"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted transition-colors"
                  >
                    <User className="h-3.5 w-3.5 text-muted-foreground" />
                    My profile
                  </Link>

                  {/* Logout */}
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center gap-2 px-3 py-2 text-sm text-destructive hover:bg-muted transition-colors"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    Sign out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link
                href="/auth/login"
                className="rounded-md px-3 py-1.5 text-sm font-medium hover:bg-muted transition-colors"
              >
                Sign in
              </Link>
              <Link
                href="/auth/register"
                className="rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
              >
                Get started
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}

function userInitials(nameOrEmail: string): string {
  const parts = (nameOrEmail ?? '').trim().split(/\s+/)
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase()
  return (nameOrEmail ?? '?').slice(0, 2).toUpperCase()
}
