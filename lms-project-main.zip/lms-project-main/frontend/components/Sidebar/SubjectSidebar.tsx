'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { X } from 'lucide-react'

import { cn } from '@/lib/utils'
import type { SubjectTree } from '@/lib/apiClient'
import { useSidebarStore } from '@/store/sidebarStore'
import { SectionItem } from '@/components/section-item'
import type { Section } from '@/components/Sidebar'

function mapTreeToSections(tree: SubjectTree): Section[] {
  return tree.sections.map((sec) => ({
    id: String(sec.id),
    title: sec.title?.trim() || 'Section',
    videos: sec.videos.map((v) => ({
      id: String(v.id),
      title: v.title?.trim() || 'Video',
      completed: v.is_completed,
      locked: v.locked,
    })),
  }))
}

type SubjectSidebarProps = {
  subjectId: string
  activeVideoId?: string
  isOpen?: boolean
  onClose?: () => void
}

export function SubjectSidebar({
  subjectId,
  activeVideoId,
  isOpen = true,
  onClose,
}: SubjectSidebarProps) {
  const router = useRouter()
  const tree = useSidebarStore((s) => s.tree)
  const loading = useSidebarStore((s) => s.loading)
  const error = useSidebarStore((s) => s.error)
  const fetchTree = useSidebarStore((s) => s.fetchTree)

  useEffect(() => {
    void fetchTree(subjectId)
  }, [subjectId, fetchTree])

  const sections: Section[] =
    tree && String(tree.id) === subjectId ? mapTreeToSections(tree) : []

  return (
    <>
      {/* Mobile backdrop — visible when sidebar is open */}
      {isOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 md:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        className={cn(
          'fixed left-0 top-16 z-40 h-[calc(100vh-4rem)] w-64 overflow-y-auto border-r border-border bg-background',
          'transform transition-transform duration-300 md:static md:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className="relative space-y-4 p-6">
          <button
            type="button"
            onClick={onClose}
            className="absolute right-4 top-4 rounded-md p-2 transition-colors hover:bg-muted md:hidden"
          >
            <X className="h-5 w-5" />
            <span className="sr-only">Close sidebar</span>
          </button>

          {loading && sections.length === 0 && !error && (
            <p className="text-sm text-muted-foreground">Loading lessons…</p>
          )}

          {error && (
            <p className="text-sm text-muted-foreground" role="alert">
              {error}
            </p>
          )}

          {!loading && !error && sections.length === 0 && (
            <p className="text-sm text-muted-foreground">No sections yet.</p>
          )}

          <nav className="space-y-3">
            {sections.map((section) => (
              <SectionItem
                key={section.id}
                id={section.id}
                title={section.title}
                videos={section.videos}
                activeVideoId={activeVideoId}
                onVideoClick={(videoId) => {
                  router.push(`/subjects/${subjectId}/lessons/${videoId}`)
                  onClose?.()
                }}
              />
            ))}
          </nav>
        </div>
      </aside>
    </>
  )
}
