'use client'

import { X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { SectionItem, type Video } from '../section-item'

export interface Section {
  id: string
  title: string
  videos: Video[]
}

interface SidebarProps {
  sections: Section[]
  activeVideoId?: string
  onVideoClick?: (videoId: string) => void
  isOpen?: boolean
  onClose?: () => void
}

export function Sidebar({
  sections,
  activeVideoId,
  onVideoClick,
  isOpen = true,
  onClose,
}: SidebarProps) {
  return (
    <>
      {/* Mobile Overlay */}
      {!isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed md:static top-16 left-0 h-[calc(100vh-4rem)] w-64 border-r border-border bg-background overflow-y-auto z-40',
          'transform transition-transform duration-300 md:transform-none',
          'md:translate-x-0',
          !isOpen && '-translate-x-full'
        )}
      >
        <div className="p-6 space-y-6">
          {/* Close Button (Mobile) */}
          <button
            onClick={onClose}
            className="md:hidden absolute top-4 right-4 p-2 hover:bg-muted rounded-md transition-colors"
          >
            <X className="h-5 w-5" />
            <span className="sr-only">Close sidebar</span>
          </button>

          {/* Course Sections */}
          <nav className="space-y-3">
            {sections.map((section) => (
              <SectionItem
                key={section.id}
                id={section.id}
                title={section.title}
                videos={section.videos}
                activeVideoId={activeVideoId}
                onVideoClick={(videoId) => {
                  onVideoClick?.(videoId)
                  // Close sidebar on mobile after selecting a video
                  onClose?.()
                }}
              />
            ))}
          </nav>
        </div>
      </aside>
    </>
  )
}
