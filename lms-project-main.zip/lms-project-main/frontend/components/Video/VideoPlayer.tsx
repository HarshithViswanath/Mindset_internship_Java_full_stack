'use client'

import { useCallback, useEffect, useRef } from 'react'
import YouTube, { type YouTubeEvent, type YouTubePlayer } from 'react-youtube'

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Extract the YouTube video ID from a full URL or a bare ID string. */
function extractYouTubeId(urlOrId: string): string {
  try {
    const url = new URL(urlOrId)
    // youtu.be/<id>
    if (url.hostname === 'youtu.be') return url.pathname.slice(1)
    // youtube.com/watch?v=<id>
    const v = url.searchParams.get('v')
    if (v) return v
    // youtube.com/embed/<id>
    const parts = url.pathname.split('/')
    return parts[parts.length - 1]
  } catch {
    // Not a URL — assume it's already the bare video ID
    return urlOrId
  }
}

// ─── Types ────────────────────────────────────────────────────────────────────

export type VideoPlayerProps = {
  src: string
  startTime?: number
  /** Called periodically with the current playback position (seconds). */
  onProgress?: (currentTime: number) => void
  /** Called once when the video ends. */
  onCompleted?: () => void
}

// ─── Component ────────────────────────────────────────────────────────────────

const PROGRESS_INTERVAL_MS = 5_000 // send an update every 5 s of playback

export default function VideoPlayer({
  src,
  startTime = 0,
  onProgress,
  onCompleted,
}: VideoPlayerProps) {
  const playerRef = useRef<YouTubePlayer | null>(null)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const lastReportedRef = useRef<number>(startTime)
  const hasAppliedStartTimeRef = useRef(false)

  const videoId = extractYouTubeId(src)

  const applyStartTime = useCallback((timeInSeconds: number) => {
    if (!playerRef.current) return
    if (hasAppliedStartTimeRef.current) return
    if (timeInSeconds <= 0) return

    try {
      void Promise.resolve(playerRef.current.seekTo(timeInSeconds, true)).finally(() => {
        lastReportedRef.current = timeInSeconds
        hasAppliedStartTimeRef.current = true
      })
    } catch {
      // Player not ready yet
    }
  }, [])

  // ── Flush the last-known position ────────────────────────────────────────

  const flushProgress = useCallback(() => {
    if (!playerRef.current) return
    try {
      // getCurrentTime returns a Promise<number> in youtube-player
      void Promise.resolve(playerRef.current.getCurrentTime()).then((t) => {
        if (t !== lastReportedRef.current) {
          lastReportedRef.current = t
          onProgress?.(t)
        }
      })
    } catch {
      // Player not ready yet
    }
  }, [onProgress])

  // ── Start / stop the polling interval ────────────────────────────────────

  const stopPolling = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
  }, [])

  const startPolling = useCallback(() => {
    stopPolling()
    intervalRef.current = setInterval(flushProgress, PROGRESS_INTERVAL_MS)
  }, [flushProgress, stopPolling])

  // Cleanup on unmount — flush one last time so we don't lose position
  useEffect(() => {
    return () => {
      flushProgress()
      stopPolling()
    }
  }, [flushProgress, stopPolling])

  useEffect(() => {
    if (startTime <= 0) {
      lastReportedRef.current = 0
      return
    }

    applyStartTime(startTime)
  }, [applyStartTime, startTime])

  // ── YouTube event handlers ────────────────────────────────────────────────

  function handleReady(event: YouTubeEvent) {
    playerRef.current = event.target
    applyStartTime(startTime)
  }

  function handlePlay(_event: YouTubeEvent<number>) {
    startPolling()
  }

  function handlePause(_event: YouTubeEvent<number>) {
    flushProgress()
    stopPolling()
  }

  function handleEnd(_event: YouTubeEvent<number>) {
    flushProgress()
    stopPolling()
    onCompleted?.()
  }

  function handleError(_event: YouTubeEvent<number>) {
    stopPolling()
  }

  // ── Render ────────────────────────────────────────────────────────────────

  const opts = {
    width: '100%',
    height: '100%',
    playerVars: {
      autoplay: 0 as const,
      start: Math.floor(startTime),
      rel: 0 as const,
      modestbranding: 1 as const,
    },
  }

  return (
    <div
      className="relative w-full overflow-hidden rounded-lg bg-black"
      style={{ aspectRatio: '16/9' }}
    >
      <YouTube
        videoId={videoId}
        opts={opts}
        onReady={handleReady}
        onPlay={handlePlay}
        onPause={handlePause}
        onEnd={handleEnd}
        onError={handleError}
        className="absolute inset-0 h-full w-full"
        iframeClassName="h-full w-full"
      />
    </div>
  )
}
