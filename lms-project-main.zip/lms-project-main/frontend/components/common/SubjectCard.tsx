import Link from 'next/link'

export type SubjectCardProps = {
  id: number | string
  title: string
  description: string
}

export function SubjectCard({ id, title, description }: SubjectCardProps) {
  return (
    <Link
      href={`/subjects/${id}`}
      className="block rounded-md border border-border bg-card p-4 transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
    >
      <h2 className="font-medium text-foreground">{title}</h2>
      {description ? (
        <p className="mt-1 text-sm text-muted-foreground line-clamp-3">
          {description}
        </p>
      ) : (
        <p className="mt-1 text-sm text-muted-foreground italic">No description</p>
      )}
    </Link>
  )
}
