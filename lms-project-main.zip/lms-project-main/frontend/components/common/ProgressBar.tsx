'use client'

type ProgressBarProps = {
  value: number
  className?: string
}

export function ProgressBar({
  value,
  className,
}: ProgressBarProps) {
  const normalizedValue = Math.max(0, Math.min(100, value))

  return (
    <div
      className={`h-2 overflow-hidden rounded-full bg-muted ${className ?? ''}`.trim()}
      aria-hidden="true"
    >
      <div
        className="h-full rounded-full bg-foreground transition-[width]"
        style={{ width: `${normalizedValue}%` }}
      />
    </div>
  )
}
