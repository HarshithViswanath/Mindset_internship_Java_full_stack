'use client'

import { CheckCircle2, Lock } from 'lucide-react'

import { cn } from '@/lib/utils'

interface VideoItemProps {
  id: string
  title: string
  completed?: boolean
  locked?: boolean
  isActive?: boolean
  onClick?: (id: string) => void
}

export function VideoItem({
  id,
  title,
  completed = false,
  locked = false,
  isActive = false,
  onClick,
}: VideoItemProps) {
  return (
    <button
      type="button"
      onClick={() => {
        if (locked) return
        onClick?.(id)
      }}
      disabled={locked}
      className={cn(
        'flex w-full items-start justify-between gap-3 rounded-md px-4 py-3 text-left transition-colors duration-200',
        'border border-transparent',
        isActive &&
          'border-border bg-accent text-accent-foreground shadow-sm',
        locked
          ? 'cursor-not-allowed opacity-60'
          : !isActive && 'text-foreground hover:bg-muted',
      )}
    >
      <span
        className={cn(
          'min-w-0 flex-1 text-sm',
          isActive && 'font-medium',
        )}
      >
        {title}
      </span>

      <span className="flex shrink-0 items-center gap-1.5">
        {completed ? (
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" aria-hidden />
        ) : locked ? (
          <Lock className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
        ) : (
          <span
            className="mt-0.5 h-4 w-4 shrink-0 rounded-full border border-border"
            aria-hidden
          />
        )}
      </span>
    </button>
  )
}
