import { create } from 'zustand'

import { ApiError, getSubjectTree, type SubjectTree } from '@/lib/apiClient'

export type SidebarState = {
  tree: SubjectTree | null
  loading: boolean
  error: string | null
  fetchTree: (subjectId: string) => Promise<void>
}

export const useSidebarStore = create<SidebarState>((set) => ({
  tree: null,
  loading: false,
  error: null,

  fetchTree: async (subjectId: string) => {
    set({ loading: true, error: null, tree: null })

    try {
      const tree = await getSubjectTree(subjectId)
      set({ tree, loading: false, error: null })
    } catch (err) {
      const message =
        err instanceof ApiError
          ? err.status === 401 || err.status === 403
            ? 'Sign in and enroll to view this subject.'
            : `Could not load lessons (${err.status}).`
          : err instanceof Error
            ? err.message
            : 'Could not load subject tree.'
      set({ tree: null, loading: false, error: message })
    }
  },
}))
