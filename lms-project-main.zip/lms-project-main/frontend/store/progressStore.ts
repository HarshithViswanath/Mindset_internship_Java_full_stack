import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { useAuthStore } from './authStore'
import { SubjectTree } from '@/lib/apiClient'

export type LessonProgress = {
  completed: boolean
  completedAt: number
  subjectId: string | number
}

export type UserProgress = Record<string, LessonProgress> // key is string(lessonId)

export type ProgressState = {
  progress: UserProgress
  markAsComplete: (lessonId: string | number, subjectId: string | number) => void
  isCompleted: (lessonId: string | number) => boolean
  getSubjectProgressStats: (tree: SubjectTree | null | undefined) => {
    completedLessons: number
    totalLessons: number
    progressPercent: number
  }
  getLastIncompleteLesson: (tree: SubjectTree | null | undefined) => string | number | null
}

const getStorageKey = () => {
  const user = useAuthStore.getState().user
  if (!user) return 'lms_progress_guest'
  return `lms_progress_${user.id}`
}

export const useProgressStore = create<ProgressState>((set, get) => ({
  progress: {},

  markAsComplete: (lessonId, subjectId) => {
    if (typeof window === 'undefined') return
    const key = getStorageKey()
    const currentStr = localStorage.getItem(key)
    const current: UserProgress = currentStr ? JSON.parse(currentStr) : {}
    
    const id = String(lessonId)
    const updated = {
      ...current,
      [id]: {
        completed: true,
        completedAt: Date.now(),
        subjectId: String(subjectId)
      }
    }
    
    localStorage.setItem(key, JSON.stringify(updated))
    set({ progress: updated })
  },

  isCompleted: (lessonId) => {
    return !!get().progress[String(lessonId)]?.completed
  },

  getSubjectProgressStats: (tree) => {
    if (!tree) return { completedLessons: 0, totalLessons: 0, progressPercent: 0 }
    const totalVideos = tree.sections.flatMap((s) => s.videos)
    const totalLessons = totalVideos.length
    if (totalLessons === 0) return { completedLessons: 0, totalLessons: 0, progressPercent: 0 }
    
    const stateProgress = get().progress
    const completedLessons = totalVideos.filter(v => stateProgress[String(v.id)]?.completed).length
    
    return {
      completedLessons,
      totalLessons,
      progressPercent: Math.round((completedLessons / totalLessons) * 100)
    }
  },

  getLastIncompleteLesson: (tree) => {
    if (!tree) return null
    const videos = tree.sections.flatMap((s) => s.videos)
    if (videos.length === 0) return null
    
    const stateProgress = get().progress
    const incomplete = videos.find(v => !stateProgress[String(v.id)]?.completed)
    return incomplete ? incomplete.id : null
  }
}))

// Hook that syncs state on mount and login
export function useSharedProgress() {
  const store = useProgressStore()
  
  if (typeof window !== 'undefined') {
    const key = getStorageKey()
    const currentStr = localStorage.getItem(key)
    if (currentStr) {
      try {
        const parsed = JSON.parse(currentStr)
        // Sync locally only if distinct (simplistic diff)
        if (Object.keys(store.progress).length !== Object.keys(parsed).length) {
          useProgressStore.setState({ progress: parsed })
        }
      } catch {
        useProgressStore.setState({ progress: {} })
      }
    }
  }

  return store
}

export function initProgress() {
  if (typeof window === 'undefined') return
  const key = getStorageKey()
  const currentStr = localStorage.getItem(key)
  if (currentStr) {
    try {
      useProgressStore.setState({ progress: JSON.parse(currentStr) })
    } catch {
      useProgressStore.setState({ progress: {} })
    }
  } else {
    useProgressStore.setState({ progress: {} })
  }
}
