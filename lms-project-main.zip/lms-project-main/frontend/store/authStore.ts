import { create } from 'zustand'
import { apiFetch, ApiError } from '@/lib/apiClient'

// ─── Types ────────────────────────────────────────────────────────────────────

export type AuthUser = {
  id: string | number
  name: string | null
  email: string
  role?: string
}

type ApiSuccessEnvelope<T> = {
  success: true
  data: T
}

type AuthResponse = {
  user: AuthUser
  accessToken: string
  refreshToken?: string
}

// ─── State ────────────────────────────────────────────────────────────────────

export type AuthState = {
  user: AuthUser | null
  accessToken: string | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null

  // ── Actions ─────────────────────────────────────────────────────────────
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  refreshToken: () => Promise<boolean>
  clearError: () => void
  /** Called once on app boot to rehydrate from localStorage. */
  rehydrate: () => void
}

const ACCESS_TOKEN_KEY = 'lms_access_token'
const USER_KEY = 'lms_user'

// ─── Store ────────────────────────────────────────────────────────────────────

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  accessToken: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,

  // ── Rehydrate from localStorage ────────────────────────────────────────

  rehydrate: () => {
    if (typeof window === 'undefined') return
    try {
      const token = localStorage.getItem(ACCESS_TOKEN_KEY)
      const userRaw = localStorage.getItem(USER_KEY)
      if (token && userRaw) {
        const user = JSON.parse(userRaw) as AuthUser
        set({ accessToken: token, user, isAuthenticated: true })
      }
    } catch {
      // Corrupted storage — start clean
      localStorage.removeItem(ACCESS_TOKEN_KEY)
      localStorage.removeItem(USER_KEY)
    }
  },

  // ── Login ──────────────────────────────────────────────────────────────

  login: async (email, password) => {
    set({ isLoading: true, error: null })
    try {
      const envelope = await apiFetch<ApiSuccessEnvelope<AuthResponse>>(
        '/auth/login',
        { method: 'POST', body: { email, password }, credentials: 'include' },
      )
      const { user, accessToken } = envelope.data
      localStorage.setItem(ACCESS_TOKEN_KEY, accessToken)
      localStorage.setItem(USER_KEY, JSON.stringify(user))
      set({ user, accessToken, isAuthenticated: true, isLoading: false, error: null })
    } catch (err) {
      const message = extractErrorMessage(err, 'Invalid email or password.')
      set({ isLoading: false, error: message })
      throw err
    }
  },

  // ── Register ───────────────────────────────────────────────────────────

  register: async (name, email, password) => {
    set({ isLoading: true, error: null })
    try {
      const envelope = await apiFetch<ApiSuccessEnvelope<AuthResponse>>(
        '/auth/register',
        { method: 'POST', body: { name, email, password }, credentials: 'include' },
      )
      const { user, accessToken } = envelope.data
      localStorage.setItem(ACCESS_TOKEN_KEY, accessToken)
      localStorage.setItem(USER_KEY, JSON.stringify(user))
      set({ user, accessToken, isAuthenticated: true, isLoading: false, error: null })
    } catch (err) {
      const message = extractErrorMessage(err, 'Registration failed. Please try again.')
      set({ isLoading: false, error: message })
      throw err
    }
  },

  // ── Logout ─────────────────────────────────────────────────────────────

  logout: async () => {
    const { accessToken } = get()
    // Attempt graceful server-side logout (best effort)
    if (accessToken) {
      try {
        await apiFetch('/auth/logout', {
          method: 'POST',
          credentials: 'include',
          headers: { Authorization: `Bearer ${accessToken}` },
        })
      } catch {
        // Ignore — we clear client state regardless
      }
    }
    localStorage.removeItem(ACCESS_TOKEN_KEY)
    localStorage.removeItem(USER_KEY)
    set({ user: null, accessToken: null, isAuthenticated: false, error: null })
  },

  // ── Refresh token ──────────────────────────────────────────────────────

  refreshToken: async () => {
    try {
      const envelope = await apiFetch<ApiSuccessEnvelope<{ accessToken: string }>>(
        '/auth/refresh',
        { method: 'POST', credentials: 'include' },
      )
      const { accessToken } = envelope.data
      localStorage.setItem(ACCESS_TOKEN_KEY, accessToken)
      set({ accessToken, isAuthenticated: true })
      return true
    } catch {
      // Refresh failed — full logout
      localStorage.removeItem(ACCESS_TOKEN_KEY)
      localStorage.removeItem(USER_KEY)
      set({ user: null, accessToken: null, isAuthenticated: false })
      return false
    }
  },

  clearError: () => set({ error: null }),
}))

// ─── Helpers ──────────────────────────────────────────────────────────────────

function extractErrorMessage(err: unknown, fallback: string): string {
  if (err instanceof ApiError) {
    const body = err.responseBody as Record<string, unknown> | undefined
    if (body && typeof body.message === 'string') return body.message
    if (err.status === 409) return 'An account with this email already exists.'
    if (err.status === 401) return 'Invalid email or password.'
    if (err.status === 422) return 'Please check your input and try again.'
    return `Request failed (${err.status}).`
  }
  if (err instanceof Error) return err.message
  return fallback
}
