import { create } from 'zustand'

import {
  ApiError,
  getVideo,
  type Video,
} from '@/lib/apiClient'

export type VideoState = {
  // ── Data ──────────────────────────────────────────────────────────────────
  video: Video | null
  loading: boolean
  error: string | null

  // ── Navigation ────────────────────────────────────────────────────────────
  nextVideoId: number | null
  prevVideoId: number | null

  // ── Actions ───────────────────────────────────────────────────────────────
  fetchVideo: (videoId: string) => Promise<void>
  reset: () => void
}

const initialState = {
  video: null,
  loading: false,
  error: null,
  nextVideoId: null,
  prevVideoId: null,
}

export const useVideoStore = create<VideoState>((set, get) => ({
  ...initialState,

  fetchVideo: async (videoId: string) => {
    set({ ...initialState, loading: true })

    try {
      const video = await getVideo(videoId)

      set({
        video,
        loading: false,
        error: null,
        nextVideoId: video.next_video_id,
        prevVideoId: video.prev_video_id,
      })
    } catch (err) {
      const message =
        err instanceof ApiError
          ? err.status === 401 || err.status === 403
            ? 'Sign in to watch this video.'
            : `Could not load video (${err.status}).`
          : err instanceof Error
            ? err.message
            : 'Could not load video.'
      set({ ...initialState, loading: false, error: message })
    }
  },

  reset: () => set(initialState),
}))
