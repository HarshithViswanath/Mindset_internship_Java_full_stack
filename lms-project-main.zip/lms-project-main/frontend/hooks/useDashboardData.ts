'use client'

import { useEffect, useMemo, useState } from 'react'

import {
  getFirstVideoForSubject,
  getMyEnrollments,
  getSubjectProgress,
  getSubjectTree,
  getVideoProgress,
  type Enrollment,
} from '@/lib/apiClient'

export type DashboardSubject = {
  subjectId: number
  title: string
  slug: string | null
  totalLessons: number
  completedLessons: number
  progressPercent: number
  nextLessonId: number | null
}

export type DashboardAnalytics = {
  totalLessonsCompleted: number
  totalTimeSpentSeconds: number
  overallCompletionPercent: number
}

type DashboardState = {
  enrolledSubjects: DashboardSubject[]
  continueLearning: DashboardSubject | null
  analytics: DashboardAnalytics
  loading: boolean
  error: string | null
}

function normalizeEnrollment(enrollment: Enrollment): {
  subjectId: number
  title: string
  slug: string | null
} {
  return {
    subjectId: enrollment.subject_id,
    title: enrollment.title ?? enrollment.subject_title ?? 'Untitled subject',
    slug: enrollment.slug ?? null,
  }
}

export function useDashboardData(): DashboardState {
  const [enrolledSubjects, setEnrolledSubjects] = useState<DashboardSubject[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [analytics, setAnalytics] = useState<DashboardAnalytics>({
    totalLessonsCompleted: 0,
    totalTimeSpentSeconds: 0,
    overallCompletionPercent: 0,
  })

  useEffect(() => {
    let active = true

    async function loadDashboard() {
      setLoading(true)
      setError(null)

      try {
        const enrollments = await getMyEnrollments()

        const subjectData = await Promise.all(
          enrollments.map(async (enrollment) => {
            const normalized = normalizeEnrollment(enrollment)

            const [progress, firstVideo, tree] = await Promise.all([
              getSubjectProgress(normalized.subjectId),
              getFirstVideoForSubject(normalized.subjectId).catch(() => null),
              getSubjectTree(String(normalized.subjectId)).catch(() => null),
            ])

            let timeSpentSeconds = 0

            if (tree) {
              const videoIds = tree.sections.flatMap((section) =>
                section.videos.map((video) => String(video.id)),
              )

              const videoProgressEntries = await Promise.all(
                videoIds.map((id) => getVideoProgress(id).catch(() => null)),
              )

              timeSpentSeconds = videoProgressEntries.reduce((total, entry) => {
                if (!entry) {
                  return total
                }

                return total + entry.last_position_seconds
              }, 0)
            }

            return {
              subjectId: normalized.subjectId,
              title: normalized.title,
              slug: normalized.slug,
              totalLessons: progress.total_videos,
              completedLessons: progress.completed_videos,
              progressPercent: progress.percent_complete,
              nextLessonId: firstVideo?.video_id ?? null,
              timeSpentSeconds,
            }
          }),
        )

        if (!active) return

        const normalizedSubjects = subjectData.map(({ timeSpentSeconds, ...subject }) => subject)
        const totalLessons = subjectData.reduce(
          (total, subject) => total + subject.totalLessons,
          0,
        )
        const totalLessonsCompleted = subjectData.reduce(
          (total, subject) => total + subject.completedLessons,
          0,
        )
        const totalTimeSpentSeconds = subjectData.reduce(
          (total, subject) => total + subject.timeSpentSeconds,
          0,
        )

        setEnrolledSubjects(normalizedSubjects)
        setAnalytics({
          totalLessonsCompleted,
          totalTimeSpentSeconds,
          overallCompletionPercent:
            totalLessons === 0
              ? 0
              : Math.round((totalLessonsCompleted / totalLessons) * 100),
        })
      } catch {
        if (!active) return
        setError('Could not load your dashboard right now.')
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void loadDashboard()

    return () => {
      active = false
    }
  }, [])

  const continueLearning = useMemo(() => {
    if (enrolledSubjects.length === 0) {
      return null
    }

    return (
      enrolledSubjects.find(
        (subject) =>
          subject.nextLessonId !== null &&
          subject.totalLessons > 0 &&
          subject.completedLessons < subject.totalLessons,
      ) ??
      enrolledSubjects.find(
        (subject) => subject.nextLessonId !== null,
      ) ??
      null
    )
  }, [enrolledSubjects])

  return {
    enrolledSubjects,
    continueLearning,
    analytics,
    loading,
    error,
  }
}
