import { API_BASE_URL } from './config'

export class ApiError extends Error {
  status: number
  responseBody?: unknown

  constructor(message: string, status: number, responseBody?: unknown) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.responseBody = responseBody
  }
}

export type ApiFetchOptions = {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'
  headers?: Record<string, string>
  /**
   * Querystring params appended to the request URL.
   * Values set to `undefined` are omitted.
   */
  query?: Record<string, string | number | boolean | undefined>
  body?: unknown
  signal?: AbortSignal
  /** Passed through to `fetch` (useful in Next.js App Router). */
  cache?: RequestCache
  next?: { revalidate?: number | false; tags?: string[] }
  /** Include cookies for authenticated API routes (e.g. subject tree). */
  credentials?: RequestCredentials
  /**
   * Internal flag — skip auth injection & 401 retry to prevent infinite loops
   * when called from the token-refresh path itself.
   */
  _skipAuthRetry?: boolean
}

function toQueryString(query?: ApiFetchOptions['query']) {
  if (!query) return ''

  const params = new URLSearchParams()
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined) continue
    params.set(key, String(value))
  }

  const qs = params.toString()
  return qs ? `?${qs}` : ''
}

/**
 * Read the current access-token from the auth store without causing React
 * re-renders. We use `getState()` instead of the hook so it's safe to call
 * outside React components.
 */
function getAccessToken(): string | null {
  if (typeof window === 'undefined') return null
  return localStorage.getItem('lms_access_token')
}

/**
 * Low-level JSON API fetch. Base URL is `API_BASE_URL` (default `http://localhost:3000/api`).
 * Automatically injects the `Authorization` header when a token is present.
 * On 401 → attempts one silent token refresh, then retries the original request.
 * Throws `ApiError` on non-OK HTTP status.
 */
export async function apiFetch<T>(
  path: string,
  options: ApiFetchOptions = {},
): Promise<T> {
  // Ensure the base URL always has a trailing slash so relative paths resolve correctly.
  // e.g. new URL('subjects', 'http://host/api')  → http://host/subjects  ← WRONG
  //      new URL('subjects', 'http://host/api/') → http://host/api/subjects ← CORRECT
  const base = API_BASE_URL.endsWith('/') ? API_BASE_URL : `${API_BASE_URL}/`
  const url = new URL(path.replace(/^\/+/, ''), base)

  const method = options.method ?? 'GET'
  const queryString = toQueryString(options.query)

  const headers: Record<string, string> = {
    accept: 'application/json',
    ...(options.headers ?? {}),
  }

  // Inject Bearer token (skip if caller already set Authorization header)
  if (!options._skipAuthRetry && !headers['Authorization'] && !headers['authorization']) {
    const token = getAccessToken()
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }
  }

  const hasBody = options.body !== undefined

  let body: BodyInit | undefined
  if (hasBody) {
    if (
      typeof FormData !== 'undefined' &&
      options.body instanceof FormData
    ) {
      body = options.body as unknown as FormData
    } else if (
      typeof Blob !== 'undefined' &&
      options.body instanceof Blob
    ) {
      body = options.body as unknown as Blob
    } else {
      headers['content-type'] ??= 'application/json'
      body = JSON.stringify(options.body)
    }
  }

  const res = await fetch(`${url.toString()}${queryString}`, {
    method,
    headers,
    body,
    signal: options.signal,
    cache: options.cache,
    next: options.next,
    credentials: options.credentials,
  })

  // ── 401 handler: attempt silent refresh + retry ───────────────────────────
  if (res.status === 401 && !options._skipAuthRetry) {
    const refreshed = await tryRefreshToken()
    if (refreshed) {
      // Retry with the new token — mark _skipAuthRetry to avoid loops
      return apiFetch<T>(path, { ...options, _skipAuthRetry: true })
    }
    // Refresh failed — fall through so we throw ApiError(401)
  }

  const contentType = res.headers.get('content-type') ?? ''
  const isJson = contentType.includes('application/json')

  if (!res.ok) {
    const responseBody = isJson
      ? await res.json().catch(() => undefined)
      : await res.text().catch(() => undefined)
    throw new ApiError(
      `Request failed with status ${res.status}`,
      res.status,
      responseBody,
    )
  }

  if (res.status === 204) {
    return undefined as T
  }

  if (!isJson) {
    const text = await res.text()
    return text as T
  }

  return (await res.json()) as T
}

/**
 * Attempt to refresh the access token using the refresh endpoint.
 * Avoids importing the Zustand store at module level (circular-dep risk)
 * by dynamically importing it only when needed at runtime.
 */
async function tryRefreshToken(): Promise<boolean> {
  if (typeof window === 'undefined') return false
  try {
    // Dynamic import to avoid circular dependency with authStore
    const { useAuthStore } = await import('@/store/authStore')
    return await useAuthStore.getState().refreshToken()
  } catch {
    return false
  }
}

export const apiClient = {
  get: <T>(
    path: string,
    options: Omit<ApiFetchOptions, 'method' | 'body'> = {},
  ) => apiFetch<T>(path, { ...options, method: 'GET' }),
  post: <T>(
    path: string,
    body?: unknown,
    options: Omit<ApiFetchOptions, 'method' | 'body'> = {},
  ) => apiFetch<T>(path, { ...options, method: 'POST', body }),
  put: <T>(
    path: string,
    body?: unknown,
    options: Omit<ApiFetchOptions, 'method' | 'body'> = {},
  ) => apiFetch<T>(path, { ...options, method: 'PUT', body }),
  patch: <T>(
    path: string,
    body?: unknown,
    options: Omit<ApiFetchOptions, 'method' | 'body'> = {},
  ) => apiFetch<T>(path, { ...options, method: 'PATCH', body }),
  delete: <T>(
    path: string,
    options: Omit<ApiFetchOptions, 'method' | 'body'> = {},
  ) => apiFetch<T>(path, { ...options, method: 'DELETE' }),
}

/** Matches backend `SubjectSummary` (dates arrive as ISO strings over JSON). */
export type Subject = {
  id: number
  title: string | null
  description: string | null
  slug?: string | null
  isPublished?: boolean
  createdAt?: string
  updatedAt?: string
}

type ApiSuccessEnvelope<T> = {
  success: true
  data: T
}

type SubjectsListPayload = {
  page: number
  pageSize: number
  data: Subject[]
}

function isSubjectsListPayload(value: unknown): value is SubjectsListPayload {
  if (!value || typeof value !== 'object') return false
  const v = value as Record<string, unknown>
  return Array.isArray(v.data)
}

/**
 * GET /subjects — returns published subjects (paginated on the server).
 */
export async function getSubjects(): Promise<Subject[]> {
  const envelope = await apiFetch<ApiSuccessEnvelope<unknown>>('/subjects', {
    cache: 'no-store',
  })

  if (!envelope.success || envelope.data === undefined || envelope.data === null) {
    throw new ApiError('Invalid API response: missing data', 500, envelope)
  }

  if (!isSubjectsListPayload(envelope.data)) {
    throw new ApiError('Invalid API response: subjects payload', 500, envelope.data)
  }

  return envelope.data.data
}

/** Subject hierarchy from GET /subjects/:subjectId/tree */
export type SubjectTreeVideo = {
  id: number
  title: string | null
  order_index: number | null
  is_completed: boolean
  locked: boolean
}

export type SubjectTreeSection = {
  id: number
  title: string | null
  order_index: number | null
  videos: SubjectTreeVideo[]
}

export type SubjectTree = {
  id: number
  title: string | null
  sections: SubjectTreeSection[]
}

function isSubjectTree(value: unknown): value is SubjectTree {
  if (!value || typeof value !== 'object') return false
  const v = value as Record<string, unknown>
  return typeof v.id === 'number' && Array.isArray(v.sections)
}

/**
 * GET /subjects/:subjectId/tree — requires auth + enrollment on the backend.
 * Uses `credentials: 'include'` so session cookies are sent from the browser.
 */
export async function getSubjectTree(subjectId: string): Promise<SubjectTree> {
  const path = `/subjects/${encodeURIComponent(subjectId)}/tree`
  const envelope = await apiFetch<ApiSuccessEnvelope<unknown>>(path, {
    cache: 'no-store',
    credentials: 'include',
  })

  if (!envelope.success || envelope.data === undefined || envelope.data === null) {
    throw new ApiError('Invalid API response: missing data', 500, envelope)
  }

  if (!isSubjectTree(envelope.data)) {
    throw new ApiError('Invalid API response: subject tree payload', 500, envelope.data)
  }

  return envelope.data
}

export type VideoProgress = {
  last_position_seconds: number
  is_completed: boolean
}

export async function getVideoProgress(videoId: string): Promise<VideoProgress> {
  const envelope = await apiFetch<ApiSuccessEnvelope<VideoProgress>>(
    `/progress/videos/${encodeURIComponent(videoId)}`,
    { cache: 'no-store', credentials: 'include' },
  )

  if (!envelope.success || envelope.data == null) {
    throw new ApiError('Invalid API response: video progress payload', 500, envelope)
  }

  return envelope.data
}

export async function updateVideoProgress(
  videoId: string,
  payload: VideoProgress,
): Promise<VideoProgress> {
  const envelope = await apiFetch<ApiSuccessEnvelope<VideoProgress>>(
    `/progress/videos/${encodeURIComponent(videoId)}`,
    {
      method: 'POST',
      body: payload,
      credentials: 'include',
    },
  )

  if (!envelope.success || envelope.data == null) {
    throw new ApiError('Invalid API response: update video progress payload', 500, envelope)
  }

  return envelope.data
}

// ─── Video API helpers ────────────────────────────────────────────────────────

export type Video = {
  id: number
  title: string | null
  description: string | null
  youtube_url: string | null
  video_url?: string | null
  url?: string | null
  videoUrl?: string | null
  duration_seconds: number | null
  order_index: number | null
  locked: boolean
  unlock_reason?: string
  next_video_id: number | null
  prev_video_id: number | null
}


/**
 * GET /api/videos/:videoId
 */
export async function getVideo(videoId: string): Promise<Video> {
  const envelope = await apiFetch<ApiSuccessEnvelope<Video>>(
    `/videos/${encodeURIComponent(videoId)}`,
    { cache: 'no-store', credentials: 'include' },
  )
  if (!envelope.success || envelope.data == null) {
    throw new ApiError('Invalid API response: video payload', 500, envelope)
  }
  return envelope.data
}

// ─── Profile / Enrollment types ───────────────────────────────────────────────

export type Enrollment = {
  id: number
  subject_id: number
  subject_title: string | null
  subject_description: string | null
  enrolled_at: string
  title?: string | null
  slug?: string | null
}

type EnrollmentApiRow = {
  subject_id: number
  title: string | null
  slug: string | null
}

export type SubjectProgressSummary = {
  total_videos: number
  completed_videos: number
  percent_complete: number
}

export type FirstVideoResult = {
  video_id: number
}

export type AdminSubjectPayload = {
  title: string
  slug: string
  description?: string | null
  isPublished?: boolean
}

export type AdminSectionPayload = {
  title: string
  orderIndex: number
}

export type AdminVideoPayload = {
  title: string
  description?: string | null
  youtubeUrl: string
  orderIndex: number
  durationSeconds?: number | null
}

export type AdminSubject = {
  id: number
  title: string | null
  slug: string | null
  description: string | null
  isPublished?: boolean
}

export type AdminSection = {
  id: number
  subjectId: number
  title: string | null
  orderIndex: number | null
}

export type AdminVideo = {
  id: number
  sectionId: number
  title: string | null
  description: string | null
  youtubeUrl: string | null
  orderIndex: number | null
  durationSeconds: number | null
}

/**
 * GET /api/users/me/enrollments
 */
export async function getMyEnrollments(): Promise<Enrollment[]> {
  try {
    const envelope = await apiFetch<ApiSuccessEnvelope<EnrollmentApiRow[]>>(
      '/users/me/enrollments',
      { cache: 'no-store', credentials: 'include' },
    )
    if (!envelope.success || envelope.data == null) return []
    return envelope.data.map((row) => ({
      id: row.subject_id,
      subject_id: row.subject_id,
      subject_title: row.title,
      subject_description: null,
      enrolled_at: '',
      title: row.title,
      slug: row.slug,
    }))
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) return []
    throw err
  }
}

export async function getSubjectProgress(
  subjectId: string | number,
): Promise<SubjectProgressSummary> {
  const envelope = await apiFetch<ApiSuccessEnvelope<SubjectProgressSummary>>(
    `/progress/subjects/${encodeURIComponent(String(subjectId))}`,
    { cache: 'no-store', credentials: 'include' },
  )

  if (!envelope.success || envelope.data == null) {
    throw new ApiError('Invalid API response: subject progress payload', 500, envelope)
  }

  return envelope.data
}

export async function getFirstVideoForSubject(
  subjectId: string | number,
): Promise<FirstVideoResult> {
  const envelope = await apiFetch<ApiSuccessEnvelope<FirstVideoResult>>(
    `/subjects/${encodeURIComponent(String(subjectId))}/first-video`,
    { cache: 'no-store', credentials: 'include' },
  )

  if (!envelope.success || envelope.data == null) {
    throw new ApiError('Invalid API response: first video payload', 500, envelope)
  }

  return envelope.data
}

/**
 * POST /api/subjects/:subjectId/enroll
 */
export async function enrollInSubject(subjectId: string | number): Promise<void> {
  await apiFetch<ApiSuccessEnvelope<unknown>>(
    `/subjects/${encodeURIComponent(String(subjectId))}/enroll`,
    { method: 'POST', credentials: 'include' },
  )
}

export async function createSubject(
  payload: AdminSubjectPayload,
): Promise<AdminSubject> {
  const envelope = await apiFetch<ApiSuccessEnvelope<AdminSubject>>(
    '/subjects',
    {
      method: 'POST',
      body: payload,
      credentials: 'include',
    },
  )

  if (!envelope.success || envelope.data == null) {
    throw new ApiError('Invalid API response: create subject payload', 500, envelope)
  }

  return envelope.data
}

export async function createSection(
  subjectId: string | number,
  payload: AdminSectionPayload,
): Promise<AdminSection> {
  const envelope = await apiFetch<ApiSuccessEnvelope<AdminSection>>(
    `/subjects/${encodeURIComponent(String(subjectId))}/sections`,
    {
      method: 'POST',
      body: payload,
      credentials: 'include',
    },
  )

  if (!envelope.success || envelope.data == null) {
    throw new ApiError('Invalid API response: create section payload', 500, envelope)
  }

  return envelope.data
}

export async function createVideoRecord(
  sectionId: string | number,
  payload: AdminVideoPayload,
): Promise<AdminVideo> {
  const envelope = await apiFetch<ApiSuccessEnvelope<AdminVideo>>(
    `/sections/${encodeURIComponent(String(sectionId))}/videos`,
    {
      method: 'POST',
      body: payload,
      credentials: 'include',
    },
  )

  if (!envelope.success || envelope.data == null) {
    throw new ApiError('Invalid API response: create video payload', 500, envelope)
  }

  return envelope.data
}
