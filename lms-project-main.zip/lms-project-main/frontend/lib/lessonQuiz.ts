export type QuizQuestion = {
  id: string
  question: string
  options: string[]
  correctAnswer: string
}

export type LessonQuiz = {
  title: string
  passingScore: number
  questions: QuizQuestion[]
}

export function getLessonQuiz(videoTitle: string | null): LessonQuiz {
  const title = videoTitle?.trim() || 'this lesson'

  return {
    title: `Quick check for ${title}`,
    passingScore: 2,
    questions: [
      {
        id: 'q1',
        question: `What is the best next step after finishing ${title}?`,
        options: [
          'Review the key idea and confirm understanding',
          'Skip directly to any random lesson',
          'Close the course immediately',
        ],
        correctAnswer: 'Review the key idea and confirm understanding',
      },
      {
        id: 'q2',
        question: 'What unlocks the next lesson in this LMS?',
        options: [
          'Passing the quiz for the current lesson',
          'Refreshing the page',
          'Opening the sidebar',
        ],
        correctAnswer: 'Passing the quiz for the current lesson',
      },
      {
        id: 'q3',
        question: 'If you want to revisit the material, what should you do?',
        options: [
          'Use Replay to rewatch the lesson',
          'Delete your progress',
          'Log out and log back in',
        ],
        correctAnswer: 'Use Replay to rewatch the lesson',
      },
    ],
  }
}
