import { ApiError, getSubjects } from '@/lib/apiClient'
import { SubjectCard } from '@/components/common/SubjectCard'

export default async function Home() {
  let subjects: Awaited<ReturnType<typeof getSubjects>> = []
  let errorMessage: string | null = null

  try {
    subjects = await getSubjects()
  } catch (err) {
    const message =
      err instanceof ApiError
        ? `Could not load subjects (${err.status}).`
        : err instanceof Error
          ? err.message
          : 'Could not load subjects.'
    errorMessage = message
  }

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="mx-auto w-full max-w-3xl space-y-6">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
            LMS Subjects
          </h1>
          <p className="mt-2 text-muted-foreground">
            Choose a subject to view lessons and videos.
          </p>
        </div>

        {errorMessage ? (
          <div
            className="rounded-md border border-border bg-muted/40 px-4 py-3 text-sm text-foreground"
            role="alert"
          >
            {errorMessage}
          </div>
        ) : subjects.length === 0 ? (
          <p className="text-sm text-muted-foreground">No subjects available yet.</p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2">
            {subjects.map((subject) => (
              <li key={subject.id}>
                <SubjectCard
                  id={subject.id}
                  title={subject.title?.trim() || 'Untitled'}
                  description={subject.description?.trim() ?? ''}
                />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
