export default function Loading() {
  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="mx-auto w-full max-w-3xl space-y-6">
        <div>
          <div className="h-8 w-48 animate-pulse rounded-md bg-muted" />
          <div className="mt-2 h-4 w-64 animate-pulse rounded-md bg-muted" />
        </div>
        <ul className="grid gap-3 sm:grid-cols-2">
          {[1, 2, 3, 4].map((i) => (
            <li key={i}>
              <div className="h-24 animate-pulse rounded-lg border border-border bg-card p-4" />
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
