'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { BookOpen, LogOut, ChevronRight, GraduationCap } from 'lucide-react'

import { AuthGuard } from '@/components/Auth/AuthGuard'
import { useAuthStore } from '@/store/authStore'
import {
  getMyEnrollments,
  type Enrollment,
} from '@/lib/apiClient'
import { Button } from '@/components/ui/button'

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function ProfilePage() {
  return (
    <AuthGuard>
      <ProfileContent />
    </AuthGuard>
  )
}

// ─── Inner content ─────────────────────────────────────────────────────────────

function ProfileContent() {
  const router = useRouter()
  const { user, logout } = useAuthStore()

  const [enrollments, setEnrollments] = useState<Enrollment[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [loggingOut, setLoggingOut] = useState(false)

  useEffect(() => {
    async function load() {
      setLoading(true)
      setError(null)
      try {
        const raw = await getMyEnrollments()
        setEnrollments(raw)
      } catch {
        setError('Could not load your enrollments. Please try again.')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  async function handleLogout() {
    setLoggingOut(true)
    await logout()
    router.replace('/auth/login')
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Page header */}
      <div className="border-b border-border bg-background">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-4 sm:px-6">
          <Link href="/" className="flex items-center gap-2 text-sm font-medium">
            <BookOpen className="h-4 w-4" />
            LMS
          </Link>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            disabled={loggingOut}
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="mx-auto max-w-3xl space-y-8 px-4 py-8 sm:px-6">

        {/* User info */}
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground text-lg font-semibold select-none">
            {userInitials(user?.name ?? user?.email ?? 'U')}
          </div>
          <div>
            <h1 className="text-xl font-semibold">
              {user?.name ?? 'Your Account'}
            </h1>
            {user?.email && (
              <p className="text-sm text-muted-foreground">{user.email}</p>
            )}
          </div>
        </div>

        {/* Enrolled subjects */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Enrolled subjects
            </h2>
          </div>

          {loading ? (
            <EnrollmentsSkeleton />
          ) : error ? (
            <div
              role="alert"
              className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive"
            >
              {error}
            </div>
          ) : enrollments.length === 0 ? (
            <EmptyEnrollments />
          ) : (
            <ul className="space-y-3">
              {enrollments.map((e) => (
                <EnrollmentCard key={e.id} enrollment={e} />
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}

// ─── Sub-components ────────────────────────────────────────────────────────────

function EnrollmentCard({ enrollment: e }: { enrollment: Enrollment }) {
  return (
    <li>
      <Link
        href={`/subjects/${e.subject_id}`}
        className="group flex items-center gap-4 rounded-md border border-border bg-card p-4 transition-colors hover:bg-muted"
      >
        <div className="flex-1 min-w-0 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <p className="font-medium leading-tight line-clamp-1">
              {e.subject_title ?? 'Untitled subject'}
            </p>
          </div>
        </div>

        <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
      </Link>
    </li>
  )
}

function EnrollmentsSkeleton() {
  return (
    <ul className="space-y-3">
      {[1, 2, 3].map((i) => (
        <li key={i} className="rounded-md border border-border bg-card p-4 space-y-2">
          <div className="h-4 w-2/3 animate-pulse rounded bg-muted" />
          <div className="h-1.5 w-full animate-pulse rounded-full bg-muted" />
          <div className="h-3 w-1/3 animate-pulse rounded bg-muted" />
        </li>
      ))}
    </ul>
  )
}

function EmptyEnrollments() {
  return (
    <div className="flex flex-col items-center gap-3 rounded-md border border-border bg-card px-6 py-12 text-center">
      <GraduationCap className="h-8 w-8 text-muted-foreground" />
      <p className="text-sm font-medium">No enrollments yet</p>
      <p className="text-xs text-muted-foreground">
        Browse subjects and enroll to start tracking your progress.
      </p>
      <Link
        href="/"
        className="mt-2 rounded-md border border-border bg-background px-3 py-1.5 text-xs font-medium hover:bg-muted transition-colors"
      >
        Browse subjects
      </Link>
    </div>
  )
}

// ─── Helpers ───────────────────────────────────────────────────────────────────

function userInitials(nameOrEmail: string): string {
  const parts = nameOrEmail.trim().split(/\s+/)
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase()
  return nameOrEmail.slice(0, 2).toUpperCase()
}
