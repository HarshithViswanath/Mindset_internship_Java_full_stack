'use client'

import Link from 'next/link'
import { BookOpen, LayoutDashboard } from 'lucide-react'

import { AuthGuard } from '@/components/Auth/AuthGuard'
import { Header } from '@/components/Header'
import { ContinueLearningCard } from '@/components/dashboard/ContinueLearningCard'
import { SubjectProgressCard } from '@/components/dashboard/SubjectProgressCard'
import { useDashboardData } from '@/hooks/useDashboardData'

export default function DashboardPage() {
  return (
    <AuthGuard>
      <DashboardContent />
    </AuthGuard>
  )
}

function DashboardContent() {
  const {
    continueLearning,
    enrolledSubjects,
    analytics,
    loading,
    error,
  } = useDashboardData()

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="mx-auto max-w-5xl space-y-8 px-4 py-24 sm:px-6 lg:px-8">
        <section className="space-y-2">
          <div className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
            <LayoutDashboard className="h-3.5 w-3.5" />
            Dashboard
          </div>
          <div>
            <h1 className="text-3xl font-semibold tracking-tight text-foreground">
              Your learning progress
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Continue where you left off and track progress across your enrolled subjects.
            </p>
          </div>
        </section>

        {loading ? (
          <DashboardSkeleton />
        ) : error ? (
          <div
            role="alert"
            className="rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive"
          >
            {error}
          </div>
        ) : enrolledSubjects.length === 0 ? (
          <EmptyDashboard />
        ) : (
          <>
            <section className="grid gap-4 sm:grid-cols-3">
              <AnalyticsCard
                label="Total lessons completed"
                value={String(analytics.totalLessonsCompleted)}
              />
              <AnalyticsCard
                label="Total time spent"
                value={formatDuration(analytics.totalTimeSpentSeconds)}
              />
              <AnalyticsCard
                label="Overall completion"
                value={`${analytics.overallCompletionPercent}%`}
              />
            </section>

            {continueLearning && (
              <ContinueLearningCard subject={continueLearning} />
            )}

            <section className="space-y-4">
              <div className="space-y-1">
                <h2 className="text-lg font-semibold text-foreground">Subject Progress</h2>
                <p className="text-sm text-muted-foreground">
                  A quick view of your completion status across all enrolled subjects.
                </p>
              </div>

              <ul className="space-y-3">
                {enrolledSubjects.map((subject) => (
                  <SubjectProgressCard
                    key={subject.subjectId}
                    subject={subject}
                  />
                ))}
              </ul>
            </section>
          </>
        )}
      </main>
    </div>
  )
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        {[1, 2, 3].map((item) => (
          <div
            key={item}
            className="rounded-xl border border-border bg-card p-5 shadow-sm"
          >
            <div className="space-y-3">
              <div className="h-4 w-1/2 animate-pulse rounded bg-muted" />
              <div className="h-7 w-1/3 animate-pulse rounded bg-muted" />
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="space-y-3">
          <div className="h-5 w-32 animate-pulse rounded bg-muted" />
          <div className="h-7 w-1/2 animate-pulse rounded bg-muted" />
          <div className="h-4 w-1/3 animate-pulse rounded bg-muted" />
          <div className="h-10 w-40 animate-pulse rounded bg-muted" />
        </div>
      </div>

      <div className="space-y-3">
        {[1, 2, 3].map((item) => (
          <div
            key={item}
            className="rounded-xl border border-border bg-card p-5 shadow-sm"
          >
            <div className="space-y-3">
              <div className="h-5 w-1/3 animate-pulse rounded bg-muted" />
              <div className="h-4 w-1/4 animate-pulse rounded bg-muted" />
              <div className="h-2 w-full animate-pulse rounded-full bg-muted" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function AnalyticsCard({
  label,
  value,
}: {
  label: string
  value: string
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-2 text-2xl font-semibold text-foreground">{value}</p>
    </div>
  )
}

function formatDuration(totalSeconds: number): string {
  const hours = Math.floor(totalSeconds / 3600)
  const minutes = Math.floor((totalSeconds % 3600) / 60)

  if (hours === 0) {
    return `${minutes}m`
  }

  if (minutes === 0) {
    return `${hours}h`
  }

  return `${hours}h ${minutes}m`
}

function EmptyDashboard() {
  return (
    <div className="rounded-xl border border-border bg-card px-6 py-12 text-center shadow-sm">
      <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <BookOpen className="h-6 w-6" />
      </div>
      <h2 className="mt-4 text-lg font-semibold text-foreground">No enrolled subjects yet</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Enroll in a subject to start tracking progress and resume learning from your dashboard.
      </p>
      <Link
        href="/"
        className="mt-4 inline-flex items-center justify-center rounded-md border border-border bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-muted"
      >
        Browse Subjects
      </Link>
    </div>
  )
}
