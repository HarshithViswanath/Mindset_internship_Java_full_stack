'use client'

import { useState } from 'react'
import { ShieldPlus } from 'lucide-react'

import { AuthGuard } from '@/components/Auth/AuthGuard'
import { Header } from '@/components/Header'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  ApiError,
  createSection,
  createSubject,
  createVideoRecord,
  type AdminSection,
  type AdminSubject,
  type AdminVideo,
} from '@/lib/apiClient'

export default function AdminPage() {
  return (
    <AuthGuard>
      <AdminContent />
    </AuthGuard>
  )
}

function AdminContent() {
  const [subjectForm, setSubjectForm] = useState({
    title: '',
    slug: '',
    description: '',
    isPublished: false,
  })
  const [sectionForm, setSectionForm] = useState({
    subjectId: '',
    title: '',
    orderIndex: '1',
  })
  const [videoForm, setVideoForm] = useState({
    sectionId: '',
    title: '',
    description: '',
    youtubeUrl: '',
    orderIndex: '1',
    durationSeconds: '',
  })

  const [createdSubjects, setCreatedSubjects] = useState<AdminSubject[]>([])
  const [createdSections, setCreatedSections] = useState<AdminSection[]>([])
  const [createdVideos, setCreatedVideos] = useState<AdminVideo[]>([])
  const [submitting, setSubmitting] = useState<'subject' | 'section' | 'video' | null>(null)
  const [error, setError] = useState<string | null>(null)

  async function handleCreateSubject(event: React.FormEvent) {
    event.preventDefault()
    setSubmitting('subject')
    setError(null)

    try {
      const subject = await createSubject({
        title: subjectForm.title.trim(),
        slug: subjectForm.slug.trim(),
        description: subjectForm.description.trim() || null,
        isPublished: subjectForm.isPublished,
      })

      setCreatedSubjects((current) => [subject, ...current])
      setSectionForm((current) => ({
        ...current,
        subjectId: String(subject.id),
      }))
      setSubjectForm({
        title: '',
        slug: '',
        description: '',
        isPublished: false,
      })
    } catch (err) {
      setError(getErrorMessage(err, 'Could not create subject.'))
    } finally {
      setSubmitting(null)
    }
  }

  async function handleCreateSection(event: React.FormEvent) {
    event.preventDefault()
    setSubmitting('section')
    setError(null)

    try {
      const section = await createSection(sectionForm.subjectId, {
        title: sectionForm.title.trim(),
        orderIndex: Number(sectionForm.orderIndex),
      })

      setCreatedSections((current) => [section, ...current])
      setVideoForm((current) => ({
        ...current,
        sectionId: String(section.id),
      }))
      setSectionForm((current) => ({
        ...current,
        title: '',
        orderIndex: '1',
      }))
    } catch (err) {
      setError(getErrorMessage(err, 'Could not create section.'))
    } finally {
      setSubmitting(null)
    }
  }

  async function handleCreateVideo(event: React.FormEvent) {
    event.preventDefault()
    setSubmitting('video')
    setError(null)

    try {
      const video = await createVideoRecord(videoForm.sectionId, {
        title: videoForm.title.trim(),
        description: videoForm.description.trim() || null,
        youtubeUrl: videoForm.youtubeUrl.trim(),
        orderIndex: Number(videoForm.orderIndex),
        durationSeconds: videoForm.durationSeconds
          ? Number(videoForm.durationSeconds)
          : null,
      })

      setCreatedVideos((current) => [video, ...current])
      setVideoForm((current) => ({
        ...current,
        title: '',
        description: '',
        youtubeUrl: '',
        orderIndex: '1',
        durationSeconds: '',
      }))
    } catch (err) {
      setError(getErrorMessage(err, 'Could not create video.'))
    } finally {
      setSubmitting(null)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="mx-auto max-w-5xl space-y-6 px-4 py-24 sm:px-6 lg:px-8">
        <section className="space-y-2">
          <div className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
            <ShieldPlus className="h-3.5 w-3.5" />
            Admin
          </div>
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">LMS Admin Panel</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Create subjects, sections, and lesson videos using the existing backend APIs.
            </p>
          </div>
        </section>

        {error && (
          <div
            role="alert"
            className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive"
          >
            {error}
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Create Subject</CardTitle>
              <CardDescription>Add a new subject to the LMS.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateSubject} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="subject-title">Title</Label>
                  <Input
                    id="subject-title"
                    value={subjectForm.title}
                    onChange={(event) =>
                      setSubjectForm((current) => ({ ...current, title: event.target.value }))
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject-slug">Slug</Label>
                  <Input
                    id="subject-slug"
                    value={subjectForm.slug}
                    onChange={(event) =>
                      setSubjectForm((current) => ({ ...current, slug: event.target.value }))
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject-description">Description</Label>
                  <Textarea
                    id="subject-description"
                    value={subjectForm.description}
                    onChange={(event) =>
                      setSubjectForm((current) => ({ ...current, description: event.target.value }))
                    }
                    rows={4}
                  />
                </div>

                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={subjectForm.isPublished}
                    onChange={(event) =>
                      setSubjectForm((current) => ({
                        ...current,
                        isPublished: event.target.checked,
                      }))
                    }
                  />
                  Publish immediately
                </label>

                <Button type="submit" disabled={submitting === 'subject'} className="w-full">
                  {submitting === 'subject' ? 'Creating...' : 'Create Subject'}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Add Section</CardTitle>
              <CardDescription>Create a section inside a subject.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateSection} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="section-subject-id">Subject ID</Label>
                  <Input
                    id="section-subject-id"
                    value={sectionForm.subjectId}
                    onChange={(event) =>
                      setSectionForm((current) => ({ ...current, subjectId: event.target.value }))
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="section-title">Section Title</Label>
                  <Input
                    id="section-title"
                    value={sectionForm.title}
                    onChange={(event) =>
                      setSectionForm((current) => ({ ...current, title: event.target.value }))
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="section-order">Order Index</Label>
                  <Input
                    id="section-order"
                    type="number"
                    min="1"
                    value={sectionForm.orderIndex}
                    onChange={(event) =>
                      setSectionForm((current) => ({ ...current, orderIndex: event.target.value }))
                    }
                    required
                  />
                </div>

                <Button type="submit" disabled={submitting === 'section'} className="w-full">
                  {submitting === 'section' ? 'Creating...' : 'Create Section'}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Add Video</CardTitle>
              <CardDescription>Add a YouTube lesson to a section.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateVideo} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="video-section-id">Section ID</Label>
                  <Input
                    id="video-section-id"
                    value={videoForm.sectionId}
                    onChange={(event) =>
                      setVideoForm((current) => ({ ...current, sectionId: event.target.value }))
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="video-title">Video Title</Label>
                  <Input
                    id="video-title"
                    value={videoForm.title}
                    onChange={(event) =>
                      setVideoForm((current) => ({ ...current, title: event.target.value }))
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="video-url">YouTube URL</Label>
                  <Input
                    id="video-url"
                    type="url"
                    value={videoForm.youtubeUrl}
                    onChange={(event) =>
                      setVideoForm((current) => ({ ...current, youtubeUrl: event.target.value }))
                    }
                    required
                  />
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="video-order">Order Index</Label>
                    <Input
                      id="video-order"
                      type="number"
                      min="1"
                      value={videoForm.orderIndex}
                      onChange={(event) =>
                        setVideoForm((current) => ({ ...current, orderIndex: event.target.value }))
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="video-duration">Duration (seconds)</Label>
                    <Input
                      id="video-duration"
                      type="number"
                      min="0"
                      value={videoForm.durationSeconds}
                      onChange={(event) =>
                        setVideoForm((current) => ({
                          ...current,
                          durationSeconds: event.target.value,
                        }))
                      }
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="video-description">Description</Label>
                  <Textarea
                    id="video-description"
                    value={videoForm.description}
                    onChange={(event) =>
                      setVideoForm((current) => ({ ...current, description: event.target.value }))
                    }
                    rows={3}
                  />
                </div>

                <Button type="submit" disabled={submitting === 'video'} className="w-full">
                  {submitting === 'video' ? 'Creating...' : 'Create Video'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <CreatedList
            title="Created Subjects"
            items={createdSubjects.map((subject) => ({
              id: subject.id,
              label: subject.title ?? 'Untitled subject',
              meta: subject.slug ?? 'No slug',
            }))}
          />
          <CreatedList
            title="Created Sections"
            items={createdSections.map((section) => ({
              id: section.id,
              label: section.title ?? 'Untitled section',
              meta: `Subject ${section.subjectId}`,
            }))}
          />
          <CreatedList
            title="Created Videos"
            items={createdVideos.map((video) => ({
              id: video.id,
              label: video.title ?? 'Untitled video',
              meta: `Section ${video.sectionId}`,
            }))}
          />
        </div>
      </main>
    </div>
  )
}

function CreatedList({
  title,
  items,
}: {
  title: string
  items: Array<{ id: number; label: string; meta: string }>
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nothing created yet.</p>
        ) : (
          <ul className="space-y-3">
            {items.map((item) => (
              <li key={item.id} className="rounded-md border border-border bg-background px-3 py-2">
                <p className="text-sm font-medium">{item.label}</p>
                <p className="text-xs text-muted-foreground">
                  ID: {item.id} · {item.meta}
                </p>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}

function getErrorMessage(error: unknown, fallback: string): string {
  if (error instanceof ApiError) {
    const body = error.responseBody as Record<string, unknown> | undefined
    if (body && typeof body.message === 'string') {
      return body.message
    }
  }

  if (error instanceof Error) {
    return error.message
  }

  return fallback
}
