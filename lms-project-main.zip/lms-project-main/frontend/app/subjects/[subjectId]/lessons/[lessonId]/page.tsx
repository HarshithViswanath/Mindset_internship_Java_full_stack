'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { CheckCircle, ChevronLeft, ChevronRight, Lock } from 'lucide-react'

import VideoPlayer from '@/components/Video/VideoPlayer'
import { LessonQuiz } from '@/components/quiz/LessonQuiz'
import {
  getVideoProgress,
  updateVideoProgress,
} from '@/lib/apiClient'
import { useToast } from '@/hooks/use-toast'
import { getLessonQuiz } from '@/lib/lessonQuiz'
import { useAuthStore } from '@/store/authStore'
import { useVideoStore } from '@/store/videoStore'

export default function VideoPage() {
  const params = useParams() as { subjectId: string; lessonId: string }
  const { subjectId, lessonId } = params
  const videoId = lessonId
  const router = useRouter()
  const { toast } = useToast()
  const user = useAuthStore((state) => state.user)

  const [completed, setCompleted] = useState(false)
  const [lastPositionSeconds, setLastPositionSeconds] = useState(0)
  const [showCompletionActions, setShowCompletionActions] = useState(false)
  const [showQuiz, setShowQuiz] = useState(false)
  const [playerKey, setPlayerKey] = useState(0)
  const progressLoadedRef = useRef(false)
  const lastSyncedPositionRef = useRef(0)
  const completingRef = useRef(false)
  const quizRef = useRef<HTMLDivElement | null>(null)

  const {
    video,
    loading,
    error,
    nextVideoId,
    prevVideoId,
    fetchVideo,
    reset,
  } = useVideoStore()

  const quizStorageKey = `lms_quiz_passed_${user?.id ?? 'guest'}_${videoId}`

  useEffect(() => {
    progressLoadedRef.current = false
    lastSyncedPositionRef.current = 0
    completingRef.current = false
    setCompleted(false)
    setLastPositionSeconds(0)
    setShowCompletionActions(false)
    setShowQuiz(false)
    setPlayerKey(0)

    void fetchVideo(videoId)

    void (async () => {
      try {
        const progress = await getVideoProgress(videoId)
        progressLoadedRef.current = true
        lastSyncedPositionRef.current = progress.last_position_seconds
        setLastPositionSeconds(progress.last_position_seconds)
        setCompleted(progress.is_completed)
        setShowCompletionActions(progress.is_completed)
      } catch {
        progressLoadedRef.current = true
      }
    })()

    return () => reset()
  }, [videoId, fetchVideo, reset])

  useEffect(() => {
    if (!showQuiz) {
      return
    }

    quizRef.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    })
  }, [showQuiz])

  const persistProgress = useCallback(
    async (positionSeconds: number, isCompleted: boolean) => {
      const normalizedPosition = Math.max(0, Math.floor(positionSeconds))

      if (!isCompleted && normalizedPosition === lastSyncedPositionRef.current) {
        return
      }

      const progress = await updateVideoProgress(videoId, {
        last_position_seconds: normalizedPosition,
        is_completed: isCompleted,
      })

      lastSyncedPositionRef.current = progress.last_position_seconds
      setLastPositionSeconds(progress.last_position_seconds)
      setCompleted(progress.is_completed)
    },
    [videoId],
  )

  const handleProgress = useCallback(
    (currentTime: number) => {
      if (!progressLoadedRef.current || completed) {
        return
      }

      void persistProgress(currentTime, false)
    },
    [completed, persistProgress],
  )

  const handleQuizRequired = useCallback(() => {
    if (completed) {
      setShowCompletionActions(true)
      return
    }

    setShowCompletionActions(false)
    setShowQuiz(true)
  }, [completed])

  const handleQuizPass = useCallback(() => {
    if (completed || completingRef.current) {
      setShowQuiz(false)
      setShowCompletionActions(true)
      return
    }

    completingRef.current = true

    void (async () => {
      try {
        await persistProgress(lastPositionSeconds, true)
        if (typeof window !== 'undefined') {
          window.localStorage.setItem(quizStorageKey, 'passed')
        }
        setShowQuiz(false)
        setShowCompletionActions(true)
        toast({
          title: 'Lesson completed',
          description: 'Quiz passed and progress saved.',
        })
      } finally {
        completingRef.current = false
      }
    })()
  }, [completed, lastPositionSeconds, persistProgress, quizStorageKey, toast])

  const handleReplay = useCallback(() => {
    setShowQuiz(false)
    setShowCompletionActions(false)
    setPlayerKey((current) => current + 1)
    setLastPositionSeconds(0)
  }, [])

  const handleNextLesson = useCallback(() => {
    if (nextVideoId == null) {
      return
    }

    router.push(`/subjects/${subjectId}/lessons/${nextVideoId}`)
  }, [nextVideoId, router, subjectId])

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-7 w-2/3 animate-pulse rounded-md bg-muted" />
        <div className="aspect-video w-full animate-pulse rounded-lg bg-muted" />
        <div className="h-4 w-1/2 animate-pulse rounded-md bg-muted" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="rounded-md border border-border bg-card p-6 text-center space-y-2">
        <p className="text-sm font-medium text-destructive">{error}</p>
        <Link
          href={`/subjects/${subjectId}`}
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ChevronLeft className="h-4 w-4" />
          Back to subject
        </Link>
      </div>
    )
  }

  if (!video) return null

  const videoUrl = video.video_url || video.url || video.videoUrl || video.youtube_url
  const playerStartTime = completed ? 0 : lastPositionSeconds
  const quiz = getLessonQuiz(video.title)

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">{video.title}</h1>
          {video.description && (
            <p className="mt-1 text-sm text-muted-foreground">{video.description}</p>
          )}
        </div>

        <div className="flex shrink-0 items-center gap-2">
          {completed ? (
            <span className="inline-flex items-center gap-1 rounded-full border border-border bg-card px-2.5 py-0.5 text-xs font-medium text-green-600 dark:text-green-500">
              <CheckCircle className="h-3.5 w-3.5" />
              Completed
            </span>
          ) : (
            <button
              onClick={handleQuizRequired}
              className="text-sm rounded-md bg-primary text-primary-foreground px-3 py-2 hover:bg-primary/90 transition-colors whitespace-nowrap"
            >
              Open Quiz
            </button>
          )}
          <Link
            href={`/subjects/${subjectId}`}
            className="text-sm rounded-md border border-border bg-background px-3 py-2 hover:bg-muted transition-colors whitespace-nowrap"
          >
            Back
          </Link>
        </div>
      </div>

      {video.locked ? (
        <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-lg border border-border bg-muted text-center">
          <Lock className="h-8 w-8 text-muted-foreground" />
          <div className="space-y-1">
            <p className="text-sm font-medium">This lesson is locked</p>
            <p className="text-sm text-muted-foreground">
              {video.unlock_reason ?? 'Complete the previous lesson to continue.'}
            </p>
          </div>
        </div>
      ) : !videoUrl ? (
        <div className="flex aspect-video w-full items-center justify-center rounded-lg border border-border bg-muted text-sm text-muted-foreground">
          Video not available
        </div>
      ) : videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be') ? (
        <VideoPlayer
          key={`youtube-${videoId}-${playerKey}`}
          src={videoUrl}
          startTime={playerStartTime}
          onProgress={handleProgress}
          onCompleted={handleQuizRequired}
        />
      ) : videoUrl.endsWith('.mp4') || videoUrl.includes('video/mp4') ? (
        <video
          key={`mp4-${videoId}-${playerKey}`}
          controls
          width="100%"
          className="aspect-video w-full rounded-lg bg-black"
          onPause={(event) => {
            void persistProgress(event.currentTarget.currentTime, completed)
          }}
          onEnded={handleQuizRequired}
        >
          <source src={videoUrl} type="video/mp4" />
        </video>
      ) : (
        <p className="flex aspect-video w-full items-center justify-center rounded-lg border border-border bg-muted text-sm text-muted-foreground">
          Video not available
        </p>
      )}

      {showQuiz && !completed && (
        <div ref={quizRef}>
          <LessonQuiz
            quiz={quiz}
            onPass={handleQuizPass}
          />
        </div>
      )}

      {showCompletionActions && (
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium">Lesson completed</p>
              <p className="text-sm text-muted-foreground">
                You can replay this lesson or continue when you are ready.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleReplay}
                className="rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-muted transition-colors"
              >
                Replay
              </button>
              {nextVideoId != null && (
                <button
                  type="button"
                  onClick={handleNextLesson}
                  className="rounded-md bg-primary px-3 py-2 text-sm text-primary-foreground hover:bg-primary/90 transition-colors"
                >
                  Next Lesson
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      <VideoNavigation
        subjectId={subjectId}
        prevVideoId={prevVideoId}
        nextVideoId={nextVideoId}
      />
    </div>
  )
}

function VideoNavigation({
  subjectId,
  prevVideoId,
  nextVideoId,
}: {
  subjectId: string
  prevVideoId: number | null
  nextVideoId: number | null
}) {
  if (prevVideoId == null && nextVideoId == null) return null

  return (
    <div className="flex items-center justify-between gap-2 border-t border-border pt-4">
      {prevVideoId != null ? (
        <Link
          href={`/subjects/${subjectId}/lessons/${prevVideoId}`}
          className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-muted transition-colors"
        >
          <ChevronLeft className="h-4 w-4" />
          Previous
        </Link>
      ) : (
        <div />
      )}

      {nextVideoId != null && (
        <Link
          href={`/subjects/${subjectId}/lessons/${nextVideoId}`}
          className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-muted transition-colors"
        >
          Next
          <ChevronRight className="h-4 w-4" />
        </Link>
      )}
    </div>
  )
}
