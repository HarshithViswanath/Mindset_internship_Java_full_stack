'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { Play, BookOpen, Loader2 } from 'lucide-react'

import {
  enrollInSubject,
  getFirstVideoForSubject,
  getSubjectProgress,
  type SubjectProgressSummary,
} from '@/lib/apiClient'

import { ProgressBar } from '@/components/common/ProgressBar'
import { useSidebarStore } from '@/store/sidebarStore'

export default function SubjectPage() {
  const params = useParams() as { subjectId: string }
  const { subjectId } = params
  const router = useRouter()

  const tree = useSidebarStore((s) => s.tree)
  const loading = useSidebarStore((s) => s.loading)
  const error = useSidebarStore((s) => s.error)
  const fetchTree = useSidebarStore((s) => s.fetchTree)
  const [isEnrolling, setIsEnrolling] = useState(false)
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [enrollError, setEnrollError] = useState<string | null>(null)
  const [resumeVideoId, setResumeVideoId] = useState<number | null>(null)
  const [resumeLoading, setResumeLoading] = useState(true)
  const [subjectProgress, setSubjectProgress] = useState<SubjectProgressSummary | null>(null)
  const [progressLoading, setProgressLoading] = useState(true)

  useEffect(() => {
    void fetchTree(subjectId)
  }, [subjectId, fetchTree])

  useEffect(() => {
    let active = true

    async function loadResumeVideo() {
      setResumeLoading(true)

      try {
        const result = await getFirstVideoForSubject(subjectId)

        if (!active) {
          return
        }

        setResumeVideoId(result.video_id)
      } catch {
        if (!active) {
          return
        }

        setResumeVideoId(null)
      } finally {
        if (active) {
          setResumeLoading(false)
        }
      }
    }

    void loadResumeVideo()

    return () => {
      active = false
    }
  }, [subjectId])

  useEffect(() => {
    let active = true

    async function loadSubjectProgress() {
      setProgressLoading(true)

      try {
        const progress = await getSubjectProgress(subjectId)

        if (!active) {
          return
        }

        setSubjectProgress(progress)
      } catch {
        if (!active) {
          return
        }

        setSubjectProgress(null)
      } finally {
        if (active) {
          setProgressLoading(false)
        }
      }
    }

    void loadSubjectProgress()

    return () => {
      active = false
    }
  }, [subjectId])

  useEffect(() => {
    if (resumeLoading) {
      return
    }

    if (resumeVideoId == null) {
      return
    }

    router.replace(`/subjects/${subjectId}/lessons/${resumeVideoId}`)
  }, [resumeLoading, resumeVideoId, router, subjectId])

  async function handleEnroll() {
    setIsEnrolling(true)
    setEnrollError(null)
    try {
      await enrollInSubject(subjectId)
      const [result, progress] = await Promise.all([
        getFirstVideoForSubject(subjectId),
        getSubjectProgress(subjectId).catch(() => null),
      ])
      await fetchTree(subjectId)
      setResumeVideoId(result.video_id)
      if (progress) {
        setSubjectProgress(progress)
      }
      setToastMessage('Enrolled successfully')
      setTimeout(() => setToastMessage(null), 3000)
    } catch (err: any) {
      setEnrollError(err?.message || 'Failed to enroll. Please try again.')
    } finally {
      setIsEnrolling(false)
    }
  }

  // Loading skeleton
  if ((loading && !tree) || resumeLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-1/2 animate-pulse rounded-md bg-muted" />
        <div className="h-4 w-2/3 animate-pulse rounded-md bg-muted" />
        <div className="grid gap-3 sm:grid-cols-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 animate-pulse rounded-md bg-muted" />
          ))}
        </div>
      </div>
    )
  }

  // Error state
  if (error) {
    const isEnrollmentError = error === 'Sign in and enroll to view this subject.'
    return (
      <div className="space-y-4">
        {isEnrollmentError ? (
          <div className="rounded-md border border-border bg-card p-6 text-center shadow-sm">
            <h2 className="text-xl font-semibold mb-2">Subject Required</h2>
            <p className="text-muted-foreground mb-6">
              You must be enrolled to view the lessons for this subject.
            </p>
            <button
              onClick={handleEnroll}
              disabled={isEnrolling}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 font-medium text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {isEnrolling ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              {isEnrolling ? 'Enrolling...' : 'Enroll Now'}
            </button>
            {enrollError && (
              <p className="mt-3 text-sm text-destructive">{enrollError}</p>
            )}
          </div>
        ) : (
          <div
            role="alert"
            className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive"
          >
            {error}
          </div>
        )}
        <Link href="/" className="inline-block text-sm text-muted-foreground hover:text-foreground transition-colors">
          ← Back to subjects
        </Link>
      </div>
    )
  }

  if (!tree) return null

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold">{tree.title ?? 'Subject'}</h1>
      </div>

      <div className="rounded-md border border-border bg-card p-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-medium">Progress</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {progressLoading || !subjectProgress
                ? 'Loading progress...'
                : `${subjectProgress.completed_videos} / ${subjectProgress.total_videos} lessons completed`}
            </p>
          </div>
          {!progressLoading && subjectProgress && (
            <span className="text-sm font-medium text-foreground">
              {subjectProgress.percent_complete}%
            </span>
          )}
        </div>
        <ProgressBar value={subjectProgress?.percent_complete ?? 0} />
      </div>

      {resumeVideoId != null && (
        <div className="rounded-md border border-border bg-card p-4">
          <h2 className="font-medium">
            Resume Learning
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Opening your next lesson based on saved progress.
          </p>
          <button
            onClick={() =>
              router.push(`/subjects/${subjectId}/lessons/${resumeVideoId}`)
            }
            className="mt-3 inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            <Play className="h-4 w-4" />
            Continue
          </button>
        </div>
      )}

      <div className="space-y-4">
        <h2 className="font-medium flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-muted-foreground" />
          Lessons
        </h2>

        {tree.sections.length === 0 ? (
          <p className="text-sm text-muted-foreground">No lessons available yet.</p>
        ) : (
          tree.sections.map((section) => (
            <div key={section.id} className="space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                {section.title ?? 'Section'}
              </h3>
              <ul className="space-y-1">
                {section.videos.map((video) => (
                  <li key={video.id}>
                    <Link
                      href={`/subjects/${subjectId}/lessons/${video.id}`}
                      className="flex items-center gap-3 rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-muted transition-colors"
                    >
                      <Play className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                      <span className="line-clamp-1">{video.title ?? 'Video'}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))
        )}
      </div>

      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-2 bg-green-500 text-white px-4 py-2 rounded-md shadow-lg font-medium text-sm">
          {toastMessage}
        </div>
      )}
    </div>
  )
}
