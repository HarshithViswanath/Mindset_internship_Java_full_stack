'use client'

import React, { useState } from 'react'
import { useParams } from 'next/navigation'

import { AuthGuard } from '@/components/Auth/AuthGuard'
import { Header } from '@/components/Header'
import { SubjectSidebar } from '@/components/Sidebar/SubjectSidebar'

type RouteParams = {
  subjectId: string
  lessonId?: string
}

export default function SubjectLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const params = useParams() as Partial<RouteParams>

  const subjectId =
    typeof params.subjectId === 'string' ? params.subjectId : ''
  const activeVideoId =
    typeof params.lessonId === 'string' ? params.lessonId : undefined

  const [isSidebarOpen, setIsSidebarOpen] = useState(false)

  return (
    <AuthGuard>
      <div className="flex h-screen flex-col bg-background">
        <Header onMenuClick={() => setIsSidebarOpen(true)} />

        <div className="flex flex-1 overflow-hidden pt-16">
          {subjectId ? (
            <SubjectSidebar
              subjectId={subjectId}
              activeVideoId={activeVideoId}
              isOpen={isSidebarOpen}
              onClose={() => setIsSidebarOpen(false)}
            />
          ) : null}

          <main className="flex-1 overflow-auto">
            <div className="mx-auto h-full w-full max-w-6xl p-4 sm:p-6 lg:p-8">
              {children}
            </div>
          </main>
        </div>
      </div>
    </AuthGuard>
  )
}
