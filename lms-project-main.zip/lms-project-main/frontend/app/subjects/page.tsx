/**
 * /subjects (index) — permanently redirects to the home page which lists all subjects.
 * This route has no layout guard and simply bounces the user to /.
 * Using `permanent: false` (307) is intentional — keeps SEO flexible.
 *
 * NOTE: This page is intentionally NOT wrapped in AuthGuard. The home page (/)
 * is public and handles its own subject listing. Subject detail pages at
 * /subjects/[subjectId] are protected separately via their layout.
 */
import { redirect } from 'next/navigation'

// Do not use useSearchParams or client hooks here — this is a pure server redirect.
export default function SubjectsIndexPage() {
  redirect('/')
}
