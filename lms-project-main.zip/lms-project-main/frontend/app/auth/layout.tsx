/**
 * Auth pages layout — no chrome (no header, no sidebar).
 * Clean centered layout for login/register.
 */
export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
