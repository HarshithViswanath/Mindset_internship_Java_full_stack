import javax.swing.*;
import java.awt.*;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class DigitalClock {
    private static final Color BG = new Color(0x0B0F14);
    private static final Color ACCENT = new Color(0x00E676);

    private static final DateTimeFormatter TIME_24H = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter TIME_12H = DateTimeFormatter.ofPattern("hh:mm:ss a");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy");

    private static final Map<String, ZoneId> ZONES = new LinkedHashMap<>();

    static {
        ZONES.put("System default", ZoneId.systemDefault());
        ZONES.put("UTC", ZoneId.of("UTC"));
        ZONES.put("Asia/Kolkata", ZoneId.of("Asia/Kolkata"));
        ZONES.put("America/New_York", ZoneId.of("America/New_York"));
        ZONES.put("Europe/London", ZoneId.of("Europe/London"));
        ZONES.put("Asia/Tokyo", ZoneId.of("Asia/Tokyo"));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DigitalClock::createAndShowUi);
    }

    private static void createAndShowUi() {
        JFrame frame = new JFrame("Digital Clock");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        panel.setBackground(BG);

        JLabel timeLabel = new JLabel("", SwingConstants.CENTER);
        timeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        timeLabel.setFont(new Font("Consolas", Font.BOLD, 44));
        timeLabel.setForeground(ACCENT);
        timeLabel.setOpaque(true);
        timeLabel.setBackground(BG);
        timeLabel.setBorder(BorderFactory.createEmptyBorder(10, 18, 6, 18));

        JLabel dateLabel = new JLabel("", SwingConstants.CENTER);
        dateLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        dateLabel.setForeground(new Color(0xD0D7DE));
        dateLabel.setOpaque(true);
        dateLabel.setBackground(BG);
        dateLabel.setBorder(BorderFactory.createEmptyBorder(0, 18, 12, 18));

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        controls.setBackground(BG);

        JCheckBox use12Hour = new JCheckBox("12-hour", false);
        use12Hour.setForeground(new Color(0xD0D7DE));
        use12Hour.setBackground(BG);
        use12Hour.setFocusPainted(false);

        JComboBox<String> zoneSelect = new JComboBox<>(ZONES.keySet().toArray(new String[0]));
        zoneSelect.setSelectedIndex(0);

        controls.add(use12Hour);
        controls.add(zoneSelect);

        panel.add(timeLabel);
        panel.add(dateLabel);
        panel.add(controls);
        frame.setContentPane(panel);

        Runnable update = () -> {
            ZoneId zone = ZONES.getOrDefault((String) zoneSelect.getSelectedItem(), ZoneId.systemDefault());
            ZonedDateTime now = ZonedDateTime.now(zone);
            DateTimeFormatter tf = use12Hour.isSelected() ? TIME_12H : TIME_24H;
            timeLabel.setText(now.format(tf));
            dateLabel.setText(now.format(DATE) + "  •  " + zone.getId());
        };

        Timer timer = new Timer(1000, e -> update.run());
        timer.setInitialDelay((int) (1000 - (System.currentTimeMillis() % 1000))); // align to next second
        timer.start();

        zoneSelect.addActionListener(e -> update.run());
        use12Hour.addActionListener(e -> update.run());
        update.run();

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
